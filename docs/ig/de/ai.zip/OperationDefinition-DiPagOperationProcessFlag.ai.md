# Digitale Patientenrechnung Operation ProcessFlag - Implementierungsleitfaden Digitale Patientenrechnung v1.0.8

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.0.8 - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Digitale Patientenrechnung Operation ProcessFlag**

## OperationDefinition: Digitale Patientenrechnung Operation ProcessFlag 

| | |
| :--- | :--- |
| *Offizielle URL*:https://gematik.de/fhir/dipag/OperationDefinition/ProcessFlag | *Version*:1.0.8 |
| Active Stand: 2026-07-08 | *Maschinenlesbarer Name*:DiPagProcessFlag |



## Resource Content

```json
{
  "resourceType" : "OperationDefinition",
  "id" : "DiPagOperationProcessFlag",
  "url" : "https://gematik.de/fhir/dipag/OperationDefinition/ProcessFlag",
  "version" : "1.0.8",
  "name" : "DiPagProcessFlag",
  "status" : "active",
  "kind" : "operation",
  "experimental" : false,
  "date" : "2026-07-08",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.gematik.de"
    }]
  }],
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "affectsState" : true,
  "code" : "process-flag",
  "resource" : ["DocumentReference"],
  "system" : false,
  "type" : false,
  "instance" : true,
  "parameter" : [{
    "name" : "markierung",
    "use" : "in",
    "min" : 0,
    "max" : "*",
    "documentation" : "Eine Markierung des Dokuments. Es gilt das Complete-Replacement-Prinzip; der gesamte übermittelte Markierungssatz ersetzt den bisherigen. Wird der Parameter nicht übergeben (0 Markierungen), werden alle änderbaren Markierungen entfernt (Löschen). Die Markierungen 'persönlich' und 'abgerufen durch KTR' bleiben hiervon ausgenommen.",
    "type" : "Coding",
    "part" : [{
      "name" : "markierung",
      "use" : "in",
      "min" : 1,
      "max" : "1",
      "documentation" : "Typ der Markierung, es können alle Markierungen mitgegeben werden, die Markierungen 'persönlich' und 'abgerufen durch KTR' werden aber wie oben beschrieben ignoriert.",
      "type" : "Coding",
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-rechnung-markierung-vs"
      }
    },
    {
      "name" : "zeitpunkt",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Optionaler Zeitpunkt der Markierung",
      "type" : "dateTime"
    },
    {
      "name" : "details",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Optionale Details als Freitext zur Markierung",
      "type" : "string"
    },
    {
      "name" : "artDerArchivierung",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Details zur Art der Archivierung falls Markierung vom Typ 'archiviert' ist. Constraint: Darf nur angegeben werden wenn die Markierung vom Typ 'archiviert' ist.",
      "type" : "Coding"
    },
    {
      "name" : "kostentraeger",
      "use" : "in",
      "min" : 0,
      "max" : "1",
      "documentation" : "Referenz auf den Kostenträger. Constraint: Darf nur angegeben werden wenn die Markierung vom Typ 'eingereicht-frontend', 'eingereicht-post', 'geteilt' oder 'abgerufen' ist.",
      "type" : "Reference"
    }]
  },
  {
    "name" : "meta",
    "use" : "out",
    "min" : 1,
    "max" : "1",
    "documentation" : "Vollständiges Meta-Element des Rechnungsdokuments / des Anhangs inkl. Extension (siehe DiPagDocumentReferenceMarkierung) zur Erfassung der Zusatzinformationen der Markierung",
    "type" : "Meta"
  }]
}

```
