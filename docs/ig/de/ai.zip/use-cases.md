# Use Cases - Implementierungsleitfaden Digitale Patientenrechnung v1.1.0

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.1.0 - ci-build 

* [**Table of Contents**](toc.md)
* **Use Cases**

## Use Cases

# Use Cases

Innerhalb des Feature-Dokumentes "Digitale Patientenrechnung" werden Epics und User Stories verwendet um individuelle Interaktionen, die Akteure im Digitale Patientenrechnung Prozess durchführen können, zu beschreiben.

Für Hersteller von Primärsystemen der Leistungserbringer oder Abrechnungsdienstleister werden Schnittstellen bereitgestellt für die User Stories zu den Prozessteilen:

* Übermittlung von Rechnungen durch Rechnungsersteller
* Wahl des Rechnungsempfängers
* Prüfung und Umgang mit Fehlern

Für Hersteller von Frontends der Versicherten werden Schnittstellen bereitgestellt für die User Stories zu den Prozessteilen:

* Empfang und Verwaltung von Rechnungen durch Rechnungsempfänger
* Einreichung von Rechnungen
* Einrichtung und Verwaltung von Nutzerkonten

Für Hersteller von IT-Systemen für Kostenträger werden Schnittstellen bereitgestellt für die User Stories zu den Prozessteilen:

* Einreichung von Rechnungen
* Verwaltung von Nutzerkonten

Für Hersteller des TI-Fachdienst "Digitale Patientenrechnung" sind alle oben genannten Epics relevant.

Für eine detailierte Beschreibung der Epics und User Stories siehe Abschnitt "2 Epics und User Stories" des Feature-Dokuments "Digitale Patientenrechnung".

