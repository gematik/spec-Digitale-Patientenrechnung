# Digitale Patientenrechnung Dokument ArtDerArchivierung VS - Implementierungsleitfaden Digitale Patientenrechnung v1.1.0

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.1.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Digitale Patientenrechnung Dokument ArtDerArchivierung VS**

## ValueSet: Digitale Patientenrechnung Dokument ArtDerArchivierung VS 

| | |
| :--- | :--- |
| *Offizielle URL*:https://gematik.de/fhir/dipag/ValueSet/dipag-dokument-artderarchivierung-vs | *Version*:1.1.0 |
| Active Stand: 2026-03-26 | *Maschinenlesbarer Name*:DiPagDokumentArtDerArchivierungVS |

 
ValueSet für die Angabe der Art der Archivierung eines Dokumentes (ePA oder persönliche Ablage) 

 **References** 

* [Digitale Patientenrechnung DocumentReference Markierung](StructureDefinition-dipag-documentreference-markierung.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Beschreibung der obigen Tabelle(n)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "dipag-dokument-artderarchivierung-vs",
  "url" : "https://gematik.de/fhir/dipag/ValueSet/dipag-dokument-artderarchivierung-vs",
  "version" : "1.1.0",
  "name" : "DiPagDokumentArtDerArchivierungVS",
  "title" : "Digitale Patientenrechnung Dokument ArtDerArchivierung VS",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-03-26",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.gematik.de"
    }]
  }],
  "description" : "ValueSet für die Angabe der Art der Archivierung eines Dokumentes (ePA oder persönliche Ablage)",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "compose" : {
    "include" : [{
      "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-dokument-artderarchivierung-cs"
    }]
  }
}

```
