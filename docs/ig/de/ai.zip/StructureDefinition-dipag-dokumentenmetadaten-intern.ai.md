# Digitale Patientenrechnung Dokumentenmetadaten Intern - Implementierungsleitfaden Digitale Patientenrechnung v1.1.0

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.1.0 - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Digitale Patientenrechnung Dokumentenmetadaten Intern**

## Ressourcenprofil: Digitale Patientenrechnung Dokumentenmetadaten Intern 

| | |
| :--- | :--- |
| *Offizielle URL*:https://gematik.de/fhir/dipag/StructureDefinition/dipag-dokumentenmetadaten-intern | *Version*:1.1.0 |
| Active Stand: 2026-07-08 | *Maschinenlesbarer Name*:DiPagDokumentenmetadatenIntern |

 
Dieses Profil beschreibt die Dokumentenmetadaten, wie sie im Fachdienst gehalten und an abrufende Akteure ausgeliefert werden. Es ergänzt die eingereichten Metadaten u. a. um das Rechnungs-Token, den Rechnungsstatus, Markierungen sowie die aus den strukturierten Rechnungsinhalten extrahierten Angaben (z. B. Rechnungsdatum, Gesamtbetrag, Zahlungsziel). 

**Usages:**

* Examples for this Profile: [DocumentReference/BeispielDocumentReferenceRechnungRetrieve](DocumentReference-BeispielDocumentReferenceRechnungRetrieve.md), [DocumentReference/BeispielDocumentReferenceRechnungRetrieve2](DocumentReference-BeispielDocumentReferenceRechnungRetrieve2.md), [DocumentReference/ExampleR5DocumentReference](DocumentReference-ExampleR5DocumentReference.md) and [DocumentReference/ExampleR5DocumentReferenceSonstigesDokument](DocumentReference-ExampleR5DocumentReferenceSonstigesDokument.md)
* CapabilityStatements using this Profile: [CapabilityStatement Fachdienst E-Rechnung](CapabilityStatement-DiPagCapabilityStatementFD.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/de.gematik.dipag|current/StructureDefinition/StructureDefinition-dipag-dokumentenmetadaten-intern.json)

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Schlüsselelemente-Tabelle](#tabs-key) 
*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Must-Support Comments](#tabs-isik) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings (Differential)

#### Constraints

#### Terminology Bindings

#### Constraints

| | | |
| :--- | :--- | :--- |
| DocumentReference.author |  | Der Fachdienst verknüpft alle Rechnungsdokumente mit der Telematik-ID des einreichenden Akteurs. |
| DocumentReference.author.display |  |  |
| DocumentReference.author.identifier |  |  |
| DocumentReference.content |  |  |
| DocumentReference.content:angereicherteRechnung |  |  |
| DocumentReference.content:angereicherteRechnung.attachment |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.contentType |  | Zum Zeitpunkt der Veröffentlichung werden nur PDF-Dokumente als Rechnung seitens der Leistungserbringer:in unterstützt. |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature |  | Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash der angereicherten Rechnung.Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss. |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].data |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].sigFormat |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].targetFormat |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].type |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].when |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who.identifier |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who.identifier.system |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who.identifier.value |  |  |
| DocumentReference.content:angereicherteRechnung.attachment.url |  |  |
| DocumentReference.content:angereicherteRechnung.format |  |  |
| DocumentReference.content:anhang |  |  |
| DocumentReference.content:anhang.attachment |  |  |
| DocumentReference.content:anhang.attachment.contentType |  | Zum Zeitpunkt der Veröffentlichung werden nur PDF-Dokumente als Rechnungsanhänge seitens der Leistungserbringer:in unterstützt. |
| DocumentReference.content:anhang.attachment.extension:signature |  | Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash des Anhangs. Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss. |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].data |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].sigFormat |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].targetFormat |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].type |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].when |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].who |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].who.identifier |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].who.identifier.system |  |  |
| DocumentReference.content:anhang.attachment.extension:signature.value[x].who.identifier.value |  |  |
| DocumentReference.content:anhang.attachment.url |  |  |
| DocumentReference.content:anhang.format |  |  |
| DocumentReference.content:originaleRechnung |  |  |
| DocumentReference.content:originaleRechnung.attachment |  |  |
| DocumentReference.content:originaleRechnung.attachment.contentType |  | Zum Zeitpunkt der Veröffentlichung werden nur PDF-Dokumente als Rechnung seitens der Leistungserbringer:in unterstützt. |
| DocumentReference.content:originaleRechnung.attachment.extension:signature |  | Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash der originalen Rechnung. Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss. |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].data |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].sigFormat |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].targetFormat |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].type |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].when |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who.identifier |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who.identifier.system |  |  |
| DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who.identifier.value |  |  |
| DocumentReference.content:originaleRechnung.attachment.url |  |  |
| DocumentReference.content:originaleRechnung.format |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.contentType |  | Strukturierte Rechnungsinhalte können seitens der Leistungserbringer:in sowohl als JSON als auch XML übergeben werden. |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature |  | Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash der strukturierten Rechnungsinhalte. Die strukturierten Rechnungsinhalte müssen im Format fhir+json vorhanden sein. Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss. |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].data |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].sigFormat |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].targetFormat |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].type |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].when |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who.identifier |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who.identifier.system |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who.identifier.value |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.attachment.url |  |  |
| DocumentReference.content:strukturierterRechnungsinhalt.format |  |  |
| DocumentReference.context |  |  |
| DocumentReference.context.related |  | Der Fachdienst verknüpft alle Rechnungsdokumente mit der Rechnungsempfänger:in. Die Slices werden über das Element Reference.type unterschieden und NICHT über die Auflösung der Referenz (resolve()), damit eine einzelne DocumentReference auch ohne Bundle-Kontext (z.B. als Ergebnis der $retrieve-Operation oder der Suche) validierbar bleibt. Der Fachdienst MUSS Reference.type entsprechend dem Zieltyp ('Patient' bzw. 'DocumentReference') setzen. |
| DocumentReference.context.related:anhaenge |  |  |
| DocumentReference.context.related:anhaenge.type |  |  |
| DocumentReference.context.related:patient |  |  |
| DocumentReference.context.related:patient.type |  |  |
| DocumentReference.description |  | Menschenlesbarer Titel des Dokumentes, der dem Versicherten in der UI angezeigt wird. Der Titel kann manuell erfasst oder vom Dateinamen/Metadaten abgeleitet werden. z.B. "Laborbefund vom 28.9.2023". |
| DocumentReference.extension |  |  |
| DocumentReference.extension:behandlungsart |  | Die Behandlungsart wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.extension:docRef-signature |  | Die Signatur auf Ebene der DocumentReference muss nur beim Typ Rechnung vorhanden sein unnd umfasst eine Signatur über die originale Rechnung und die strukturierten Rechnungsinhalte. |
| DocumentReference.extension:docRef-signature.value[x].data |  |  |
| DocumentReference.extension:docRef-signature.value[x].sigFormat |  |  |
| DocumentReference.extension:docRef-signature.value[x].targetFormat |  |  |
| DocumentReference.extension:docRef-signature.value[x].type |  |  |
| DocumentReference.extension:docRef-signature.value[x].when |  |  |
| DocumentReference.extension:docRef-signature.value[x].who |  |  |
| DocumentReference.extension:docRef-signature.value[x].who.identifier |  |  |
| DocumentReference.extension:docRef-signature.value[x].who.identifier.system |  |  |
| DocumentReference.extension:docRef-signature.value[x].who.identifier.value |  |  |
| DocumentReference.extension:fachrichtung |  | Die Fachrichtung wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.extension:gesamtbetrag |  | Der Gesamtbetrag wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.extension:rechnungsdatum |  | Das Rechnungsdatum wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.extension:zahlungszieldatum |  | Das Zahlungszieldatum wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.identifier |  |  |
| DocumentReference.identifier:AnhangIdentifier | Anhangs-Identifier | Eindeutiger Identifikator für Anhänge vergeben durch das RE-PS (z.B. Interne Dokumentennummer). Bei Anhängen MUSS das System eindeutig pro Leistungserbringer:in vergeben werden. |
| DocumentReference.identifier:AnhangIdentifier.system | NamingSystem des Anhangs-Identifier |  |
| DocumentReference.identifier:AnhangIdentifier.type |  |  |
| DocumentReference.identifier:AnhangIdentifier.value | Anhangs-Identifier |  |
| DocumentReference.identifier:Rechnungsnummer | Rechnungs-Nr. (der LEI) | Die Rechnungs-Nr. (der LEI) MUSS vorhanden sein. |
| DocumentReference.identifier:Rechnungsnummer.system | NamingSystem der Rechnungs-Nr. (der LEI) |  |
| DocumentReference.identifier:Rechnungsnummer.type |  |  |
| DocumentReference.identifier:Rechnungsnummer.value | Rechnungs-Nr. (der LEI) |  |
| DocumentReference.identifier:Token | Rechnungs-Token (Dokumenttoken) | Eindeutiges, vom Fachdienst vergebenes Token zur Identifikation des Dokuments beim Abruf über die Retrieve-Operation. Das Token wird als eigener Identifier geführt und ist NICHT mit der technischen DocumentReference-id identisch. Das Token MUSS so vergeben werden, dass es NICHT aus der DocumentReference-id abgeleitet werden kann (z.B. kryptographisch zufällig erzeugt). |
| DocumentReference.identifier:Token.system | NamingSystem des Rechnungs-Tokens |  |
| DocumentReference.identifier:Token.value | Rechnungs-Token (Dokumenttoken) |  |
| DocumentReference.meta.extension |  |  |
| DocumentReference.meta.extension:markierung |  | Vgl. Abschnitt '4.4.2 Markierungen' des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.meta.extension:markierung.extension:artDerArchivierung |  |  |
| DocumentReference.meta.extension:markierung.extension:artDerArchivierung.value[x] |  |  |
| DocumentReference.meta.extension:markierung.extension:details |  |  |
| DocumentReference.meta.extension:markierung.extension:details.value[x] |  |  |
| DocumentReference.meta.extension:markierung.extension:kostentraeger |  |  |
| DocumentReference.meta.extension:markierung.extension:kostentraeger.value[x] |  |  |
| DocumentReference.meta.extension:markierung.extension:kostentraeger.value[x].display |  |  |
| DocumentReference.meta.extension:markierung.extension:kostentraeger.value[x].identifier |  |  |
| DocumentReference.meta.extension:markierung.extension:markierung |  |  |
| DocumentReference.meta.extension:markierung.extension:markierung.value[x] |  |  |
| DocumentReference.meta.extension:markierung.extension:zeitpunkt |  |  |
| DocumentReference.meta.extension:markierung.extension:zeitpunkt.value[x] |  |  |
| DocumentReference.meta.tag |  | Metaangaben zur Digitalen Patientenrechnung die sich auf das Rechnungsdokument als Ganzes beziehen und nicht Teil des durch den RE-PS erstellten Dokuments sind. |
| DocumentReference.meta.tag:dipag-rechnungsstatus |  | Vgl. Abschnitt 4.4.1 Workflow einer Rechnung des Feature-Dokuments Digitale Patientenrechnung |
| DocumentReference.meta.tag:dipag-rechnungsstatus.code |  |  |
| DocumentReference.meta.tag:dipag-rechnungsstatus.system |  |  |
| DocumentReference.status |  | Versionierung von Dokumenten ist nicht unterstützt. Nur jeweils die aktuelle Version des Dokumentes wird akzeptiert. |
| DocumentReference.subject |  | Vollständiger Name der behandelten Person. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung. |
| DocumentReference.subject.display |  |  |
| DocumentReference.type |  | Kodierung des Dokumentes als 'Rechnung', sowie darüber hinausgehende Klassifizierung per KDL |
| DocumentReference.type.coding:DokumentenKlassifizierung |  |  |
| DocumentReference.type.coding:DokumentenKlassifizierung.code |  |  |
| DocumentReference.type.coding:DokumentenKlassifizierung.display |  |  |
| DocumentReference.type.coding:DokumentenKlassifizierung.system |  |  |
| DocumentReference.type.coding:Rechnungstyp |  |  |

Diese Struktur ist abgeleitet von [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

** Summary **

Mandatory: 9 elements(29 nested mandatory elements)
 Must-Support: 126 elements
 Prohibited: 4 elements

**Structures**

This structure refers to these other structures:

* [Identifier-Profil für die Telematik-ID (http://fhir.de/StructureDefinition/identifier-telematik-id)](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/StructureDefinition/identifier-telematik-id)

**Extensions**

This structure refers to these extensions:

* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-markierung](StructureDefinition-dipag-documentreference-markierung.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature](StructureDefinition-dipag-docref-signature.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-rechnungsdatum](StructureDefinition-dipag-documentreference-rechnungsdatum.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-zahlungsziel](StructureDefinition-dipag-zahlungsziel.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-gesamtbetrag](StructureDefinition-dipag-documentreference-gesamtbetrag.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-fachrichtung](StructureDefinition-dipag-docref-fachrichtung.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-behandlungsart](StructureDefinition-dipag-behandlungsart.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of DocumentReference.meta.tag
* The element 1 is sliced based on the value of DocumentReference.identifier
* The element 1 is sliced based on the value of DocumentReference.type.coding
* The element 1 is sliced based on the value of DocumentReference.content
* The element 1 is sliced based on the value of DocumentReference.context.related

 **Schlüsselelemente-Ansicht** 

#### Terminology Bindings

#### Constraints

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

#### Terminology Bindings (Differential)

#### Constraints

 **Snapshot-AnsichtView** 

#### Terminology Bindings

#### Constraints

Diese Struktur ist abgeleitet von [DocumentReference](http://hl7.org/fhir/R4/documentreference.html) 

** Summary **

Mandatory: 9 elements(29 nested mandatory elements)
 Must-Support: 126 elements
 Prohibited: 4 elements

**Structures**

This structure refers to these other structures:

* [Identifier-Profil für die Telematik-ID (http://fhir.de/StructureDefinition/identifier-telematik-id)](https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&canonical=http://fhir.de/StructureDefinition/identifier-telematik-id)

**Extensions**

This structure refers to these extensions:

* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-markierung](StructureDefinition-dipag-documentreference-markierung.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature](StructureDefinition-dipag-docref-signature.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-rechnungsdatum](StructureDefinition-dipag-documentreference-rechnungsdatum.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-zahlungsziel](StructureDefinition-dipag-zahlungsziel.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-gesamtbetrag](StructureDefinition-dipag-documentreference-gesamtbetrag.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-fachrichtung](StructureDefinition-dipag-docref-fachrichtung.md)
* [https://gematik.de/fhir/dipag/StructureDefinition/dipag-behandlungsart](StructureDefinition-dipag-behandlungsart.md)

**Slices**

This structure defines the following [Slices](http://hl7.org/fhir/R4/profiling.html#slices):

* The element 1 is sliced based on the value of DocumentReference.meta.tag
* The element 1 is sliced based on the value of DocumentReference.identifier
* The element 1 is sliced based on the value of DocumentReference.type.coding
* The element 1 is sliced based on the value of DocumentReference.content
* The element 1 is sliced based on the value of DocumentReference.context.related

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-dipag-dokumentenmetadaten-intern.csv), [Excel](../StructureDefinition-dipag-dokumentenmetadaten-intern.xlsx), [Schematron](../StructureDefinition-dipag-dokumentenmetadaten-intern.sch) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "dipag-dokumentenmetadaten-intern",
  "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-dokumentenmetadaten-intern",
  "version" : "1.1.0",
  "name" : "DiPagDokumentenmetadatenIntern",
  "title" : "Digitale Patientenrechnung Dokumentenmetadaten Intern",
  "status" : "active",
  "experimental" : false,
  "date" : "2026-07-08",
  "publisher" : "gematik GmbH",
  "contact" : [{
    "name" : "gematik GmbH",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.gematik.de"
    }]
  }],
  "description" : "Dieses Profil beschreibt die Dokumentenmetadaten, wie sie im Fachdienst gehalten und an abrufende Akteure ausgeliefert werden. Es ergänzt die eingereichten Metadaten u. a. um das Rechnungs-Token, den Rechnungsstatus, Markierungen sowie die aus den strukturierten Rechnungsinhalten extrahierten Angaben (z. B. Rechnungsdatum, Gesamtbetrag, Zahlungsziel).",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "mapping" : [{
    "identity" : "workflow",
    "uri" : "http://hl7.org/fhir/workflow",
    "name" : "Workflow Pattern"
  },
  {
    "identity" : "fhircomposition",
    "uri" : "http://hl7.org/fhir/composition",
    "name" : "FHIR Composition"
  },
  {
    "identity" : "rim",
    "uri" : "http://hl7.org/v3",
    "name" : "RIM Mapping"
  },
  {
    "identity" : "cda",
    "uri" : "http://hl7.org/v3/cda",
    "name" : "CDA (R2)"
  },
  {
    "identity" : "w5",
    "uri" : "http://hl7.org/fhir/fivews",
    "name" : "FiveWs Pattern Mapping"
  },
  {
    "identity" : "v2",
    "uri" : "http://hl7.org/v2",
    "name" : "HL7 v2 Mapping"
  },
  {
    "identity" : "xds",
    "uri" : "http://ihe.net/xds",
    "name" : "XDS metadata equivalent"
  }],
  "kind" : "resource",
  "abstract" : false,
  "type" : "DocumentReference",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/DocumentReference",
  "derivation" : "constraint",
  "differential" : {
    "element" : [{
      "id" : "DocumentReference",
      "path" : "DocumentReference",
      "constraint" : [{
        "key" : "SignaturVerpflichtendRechnung",
        "severity" : "warning",
        "human" : "Eine Signature muss vorhanden sein, falls es sich bei der DocumentReference um eine Rechnung handelt. Diese Invariante ist als Warnung eingestuft, weil in R5 zur Ausgabe entfernt wird und diese Ausgabe ohne Validierungsfehler sein soll.",
        "expression" : "type.coding.where(system = 'http://dvmd.de/fhir/CodeSystem/kdl' and code = 'AM010106').exists() and content.format.where(system = 'https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs' and code = 'originaleRechnung').exists() and content.format.where(system = 'https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs' and code = 'rechnungsinhalt').exists() implies extension.where(url = 'https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature').exists()",
        "source" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-dokumentenmetadaten-intern"
      }]
    },
    {
      "id" : "DocumentReference.id",
      "path" : "DocumentReference.id",
      "comment" : "Die technische DocumentReference-id dient ausschließlich der serverinternen Adressierung. Der Abruf eines Dokuments erfolgt nicht über die id, sondern ausschließlich über das Rechnungs-Token (siehe identifier:Token) via Retrieve-Operation. Das Token darf NICHT aus der id ableitbar sein."
    },
    {
      "id" : "DocumentReference.meta.extension",
      "path" : "DocumentReference.meta.extension",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung",
      "path" : "DocumentReference.meta.extension",
      "sliceName" : "markierung",
      "comment" : "Vgl. Abschnitt '4.4.2 Markierungen' des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-markierung"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:markierung",
      "path" : "DocumentReference.meta.extension.extension",
      "sliceName" : "markierung",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:markierung.value[x]",
      "path" : "DocumentReference.meta.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:zeitpunkt",
      "path" : "DocumentReference.meta.extension.extension",
      "sliceName" : "zeitpunkt",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:zeitpunkt.value[x]",
      "path" : "DocumentReference.meta.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:details",
      "path" : "DocumentReference.meta.extension.extension",
      "sliceName" : "details",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:details.value[x]",
      "path" : "DocumentReference.meta.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:artDerArchivierung",
      "path" : "DocumentReference.meta.extension.extension",
      "sliceName" : "artDerArchivierung",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:artDerArchivierung.value[x]",
      "path" : "DocumentReference.meta.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:kostentraeger",
      "path" : "DocumentReference.meta.extension.extension",
      "sliceName" : "kostentraeger",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:kostentraeger.value[x]",
      "path" : "DocumentReference.meta.extension.extension.value[x]",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:kostentraeger.value[x].identifier",
      "path" : "DocumentReference.meta.extension.extension.value[x].identifier",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.extension:markierung.extension:kostentraeger.value[x].display",
      "path" : "DocumentReference.meta.extension.extension.value[x].display",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.tag",
      "path" : "DocumentReference.meta.tag",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "comment" : "Metaangaben zur Digitalen Patientenrechnung die sich auf das Rechnungsdokument als Ganzes beziehen und nicht Teil des durch den RE-PS erstellten Dokuments sind.",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.tag:dipag-rechnungsstatus",
      "path" : "DocumentReference.meta.tag",
      "sliceName" : "dipag-rechnungsstatus",
      "comment" : "Vgl. Abschnitt 4.4.1 Workflow einer Rechnung des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-rechnungsstatus-vs"
      }
    },
    {
      "id" : "DocumentReference.meta.tag:dipag-rechnungsstatus.system",
      "path" : "DocumentReference.meta.tag.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.meta.tag:dipag-rechnungsstatus.code",
      "path" : "DocumentReference.meta.tag.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension",
      "path" : "DocumentReference.extension",
      "slicing" : {
        "discriminator" : [{
          "type" : "value",
          "path" : "url"
        }],
        "ordered" : false,
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature",
      "path" : "DocumentReference.extension",
      "sliceName" : "docRef-signature",
      "comment" : "Die Signatur auf Ebene der DocumentReference muss nur beim Typ Rechnung vorhanden sein unnd umfasst eine Signatur über die originale Rechnung und die strukturierten Rechnungsinhalte.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].type",
      "path" : "DocumentReference.extension.value[x].type",
      "patternCoding" : {
        "system" : "urn:iso-astm:E1762-95:2013",
        "code" : "1.2.840.10065.1.12.1.13"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].when",
      "path" : "DocumentReference.extension.value[x].when",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].who",
      "path" : "DocumentReference.extension.value[x].who",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].who.identifier",
      "path" : "DocumentReference.extension.value[x].who.identifier",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].who.identifier.system",
      "path" : "DocumentReference.extension.value[x].who.identifier.system",
      "patternUri" : "urn:ietf:rfc:3986",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].who.identifier.value",
      "path" : "DocumentReference.extension.value[x].who.identifier.value",
      "patternString" : "urn:oid:1.2.276.0.76.4.323",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].targetFormat",
      "path" : "DocumentReference.extension.value[x].targetFormat",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-restricted-mime-types-in-binary-vs"
      }
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].sigFormat",
      "path" : "DocumentReference.extension.value[x].sigFormat",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:docRef-signature.value[x].data",
      "path" : "DocumentReference.extension.value[x].data",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:rechnungsdatum",
      "path" : "DocumentReference.extension",
      "sliceName" : "rechnungsdatum",
      "comment" : "Das Rechnungsdatum wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-rechnungsdatum"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:zahlungszieldatum",
      "path" : "DocumentReference.extension",
      "sliceName" : "zahlungszieldatum",
      "comment" : "Das Zahlungszieldatum wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-zahlungsziel"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:gesamtbetrag",
      "path" : "DocumentReference.extension",
      "sliceName" : "gesamtbetrag",
      "comment" : "Der Gesamtbetrag wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-gesamtbetrag"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:fachrichtung",
      "path" : "DocumentReference.extension",
      "sliceName" : "fachrichtung",
      "comment" : "Die Fachrichtung wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-fachrichtung"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.extension:behandlungsart",
      "path" : "DocumentReference.extension",
      "sliceName" : "behandlungsart",
      "comment" : "Die Behandlungsart wird aus den strukturierten Inhalten durch den FD extrahiert. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-behandlungsart"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier",
      "path" : "DocumentReference.identifier",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Token",
      "path" : "DocumentReference.identifier",
      "sliceName" : "Token",
      "short" : "Rechnungs-Token (Dokumenttoken)",
      "comment" : "Eindeutiges, vom Fachdienst vergebenes Token zur Identifikation des Dokuments beim Abruf über die Retrieve-Operation. Das Token wird als eigener Identifier geführt und ist NICHT mit der technischen DocumentReference-id identisch. Das Token MUSS so vergeben werden, dass es NICHT aus der DocumentReference-id abgeleitet werden kann (z.B. kryptographisch zufällig erzeugt).",
      "min" : 1,
      "max" : "1",
      "patternIdentifier" : {
        "system" : "https://gematik.de/fhir/sid/dipag-token"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Token.system",
      "path" : "DocumentReference.identifier.system",
      "short" : "NamingSystem des Rechnungs-Tokens",
      "min" : 1,
      "patternUri" : "https://gematik.de/fhir/sid/dipag-token",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Token.value",
      "path" : "DocumentReference.identifier.value",
      "short" : "Rechnungs-Token (Dokumenttoken)",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Rechnungsnummer",
      "path" : "DocumentReference.identifier",
      "sliceName" : "Rechnungsnummer",
      "short" : "Rechnungs-Nr. (der LEI)",
      "comment" : "Die Rechnungs-Nr. (der LEI) MUSS vorhanden sein.",
      "min" : 0,
      "max" : "1",
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-rechnung-identifier-type-cs",
            "code" : "invoice"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Rechnungsnummer.type",
      "path" : "DocumentReference.identifier.type",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-rechnung-identifier-type-cs",
          "code" : "invoice"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Rechnungsnummer.system",
      "path" : "DocumentReference.identifier.system",
      "short" : "NamingSystem der Rechnungs-Nr. (der LEI)",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:Rechnungsnummer.value",
      "path" : "DocumentReference.identifier.value",
      "short" : "Rechnungs-Nr. (der LEI)",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:AnhangIdentifier",
      "path" : "DocumentReference.identifier",
      "sliceName" : "AnhangIdentifier",
      "short" : "Anhangs-Identifier",
      "comment" : "Eindeutiger Identifikator für Anhänge vergeben durch das RE-PS (z.B. Interne Dokumentennummer). Bei Anhängen MUSS das System eindeutig pro Leistungserbringer:in vergeben werden.",
      "min" : 0,
      "max" : "1",
      "patternIdentifier" : {
        "type" : {
          "coding" : [{
            "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-rechnung-identifier-type-cs",
            "code" : "anhang"
          }]
        }
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:AnhangIdentifier.type",
      "path" : "DocumentReference.identifier.type",
      "min" : 1,
      "patternCodeableConcept" : {
        "coding" : [{
          "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-rechnung-identifier-type-cs",
          "code" : "anhang"
        }]
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:AnhangIdentifier.system",
      "path" : "DocumentReference.identifier.system",
      "short" : "NamingSystem des Anhangs-Identifier",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.identifier:AnhangIdentifier.value",
      "path" : "DocumentReference.identifier.value",
      "short" : "Anhangs-Identifier",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.status",
      "path" : "DocumentReference.status",
      "comment" : "Versionierung von Dokumenten ist nicht unterstützt. Nur jeweils die aktuelle Version des Dokumentes wird akzeptiert.",
      "patternCode" : "current",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.type",
      "path" : "DocumentReference.type",
      "comment" : "Kodierung des Dokumentes als 'Rechnung', sowie darüber hinausgehende Klassifizierung per KDL",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.type.coding",
      "path" : "DocumentReference.type.coding",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "$this"
        }],
        "rules" : "open"
      },
      "min" : 1
    },
    {
      "id" : "DocumentReference.type.coding:DokumentenKlassifizierung",
      "path" : "DocumentReference.type.coding",
      "sliceName" : "DokumentenKlassifizierung",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-sonstigesdokument-type-vs"
      }
    },
    {
      "id" : "DocumentReference.type.coding:DokumentenKlassifizierung.system",
      "path" : "DocumentReference.type.coding.system",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.type.coding:DokumentenKlassifizierung.code",
      "path" : "DocumentReference.type.coding.code",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.type.coding:DokumentenKlassifizierung.display",
      "path" : "DocumentReference.type.coding.display",
      "min" : 1,
      "maxLength" : 1024,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.type.coding:Rechnungstyp",
      "path" : "DocumentReference.type.coding",
      "sliceName" : "Rechnungstyp",
      "min" : 0,
      "max" : "1",
      "patternCoding" : {
        "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
        "code" : "AM010106"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.subject",
      "path" : "DocumentReference.subject",
      "comment" : "Vollständiger Name der behandelten Person. Siehe Informationsmodell 'Rechnung' des Feature-Dokuments Digitale Patientenrechnung.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.subject.display",
      "path" : "DocumentReference.subject.display",
      "min" : 1,
      "maxLength" : 1024,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.author",
      "path" : "DocumentReference.author",
      "comment" : "Der Fachdienst verknüpft alle Rechnungsdokumente mit der Telematik-ID des einreichenden Akteurs.",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.author.identifier",
      "path" : "DocumentReference.author.identifier",
      "min" : 1,
      "type" : [{
        "code" : "Identifier",
        "profile" : ["http://fhir.de/StructureDefinition/identifier-telematik-id"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.author.display",
      "path" : "DocumentReference.author.display",
      "min" : 1,
      "maxLength" : 1024,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.description",
      "path" : "DocumentReference.description",
      "comment" : "Menschenlesbarer Titel des Dokumentes, der dem Versicherten in der UI angezeigt wird. Der Titel kann manuell erfasst oder vom Dateinamen/Metadaten abgeleitet werden. z.B. &quot;Laborbefund vom 28.9.2023&quot;.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content",
      "path" : "DocumentReference.content",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "format"
        }],
        "rules" : "open"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung",
      "path" : "DocumentReference.content",
      "sliceName" : "originaleRechnung",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment",
      "path" : "DocumentReference.content.attachment",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature",
      "path" : "DocumentReference.content.attachment.extension",
      "sliceName" : "signature",
      "comment" : "Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash der originalen Rechnung. Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].type",
      "path" : "DocumentReference.content.attachment.extension.value[x].type",
      "patternCoding" : {
        "system" : "urn:iso-astm:E1762-95:2013",
        "code" : "1.2.840.10065.1.12.1.13"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].when",
      "path" : "DocumentReference.content.attachment.extension.value[x].when",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who",
      "path" : "DocumentReference.content.attachment.extension.value[x].who",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who.identifier",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who.identifier.system",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.system",
      "patternUri" : "urn:ietf:rfc:3986",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].who.identifier.value",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.value",
      "patternString" : "urn:oid:1.2.276.0.76.4.323",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].targetFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].targetFormat",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-restricted-mime-types-in-binary-vs"
      }
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].sigFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].sigFormat",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.extension:signature.value[x].data",
      "path" : "DocumentReference.content.attachment.extension.value[x].data",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.contentType",
      "path" : "DocumentReference.content.attachment.contentType",
      "comment" : "Zum Zeitpunkt der Veröffentlichung werden nur PDF-Dokumente als Rechnung seitens der Leistungserbringer:in unterstützt.",
      "min" : 1,
      "patternCode" : "application/pdf",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.data",
      "path" : "DocumentReference.content.attachment.data",
      "comment" : "Die angereicherte Rechnung wird durch den FD direkt als Binary-Ressource unter attachment.url referenziert.",
      "max" : "0"
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.attachment.url",
      "path" : "DocumentReference.content.attachment.url",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:originaleRechnung.format",
      "path" : "DocumentReference.content.format",
      "min" : 1,
      "patternCoding" : {
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
        "code" : "originaleRechnung"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung",
      "path" : "DocumentReference.content",
      "sliceName" : "angereicherteRechnung",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment",
      "path" : "DocumentReference.content.attachment",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature",
      "path" : "DocumentReference.content.attachment.extension",
      "sliceName" : "signature",
      "comment" : "Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash der angereicherten Rechnung.Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].type",
      "path" : "DocumentReference.content.attachment.extension.value[x].type",
      "patternCoding" : {
        "system" : "urn:iso-astm:E1762-95:2013",
        "code" : "1.2.840.10065.1.12.1.13"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].when",
      "path" : "DocumentReference.content.attachment.extension.value[x].when",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who",
      "path" : "DocumentReference.content.attachment.extension.value[x].who",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who.identifier",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who.identifier.system",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.system",
      "patternUri" : "urn:ietf:rfc:3986",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].who.identifier.value",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.value",
      "patternString" : "urn:oid:1.2.276.0.76.4.323",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].targetFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].targetFormat",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-restricted-mime-types-in-binary-vs"
      }
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].sigFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].sigFormat",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.extension:signature.value[x].data",
      "path" : "DocumentReference.content.attachment.extension.value[x].data",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.contentType",
      "path" : "DocumentReference.content.attachment.contentType",
      "comment" : "Zum Zeitpunkt der Veröffentlichung werden nur PDF-Dokumente als Rechnung seitens der Leistungserbringer:in unterstützt.",
      "min" : 1,
      "patternCode" : "application/pdf",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.data",
      "path" : "DocumentReference.content.attachment.data",
      "comment" : "Die angereicherte Rechnung wird durch den FD direkt als Binary-Ressource unter attachment.url referenziert.",
      "max" : "0"
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.attachment.url",
      "path" : "DocumentReference.content.attachment.url",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:angereicherteRechnung.format",
      "path" : "DocumentReference.content.format",
      "min" : 1,
      "patternCoding" : {
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
        "code" : "angereichertesPDF"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt",
      "path" : "DocumentReference.content",
      "sliceName" : "strukturierterRechnungsinhalt",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment",
      "path" : "DocumentReference.content.attachment",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature",
      "path" : "DocumentReference.content.attachment.extension",
      "sliceName" : "signature",
      "comment" : "Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash der strukturierten Rechnungsinhalte. Die strukturierten Rechnungsinhalte müssen im Format fhir+json vorhanden sein. Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].type",
      "path" : "DocumentReference.content.attachment.extension.value[x].type",
      "patternCoding" : {
        "system" : "urn:iso-astm:E1762-95:2013",
        "code" : "1.2.840.10065.1.12.1.13"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].when",
      "path" : "DocumentReference.content.attachment.extension.value[x].when",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who",
      "path" : "DocumentReference.content.attachment.extension.value[x].who",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who.identifier",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who.identifier.system",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.system",
      "patternUri" : "urn:ietf:rfc:3986",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].who.identifier.value",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.value",
      "patternString" : "urn:oid:1.2.276.0.76.4.323",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].targetFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].targetFormat",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-restricted-mime-types-in-binary-vs"
      }
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].sigFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].sigFormat",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.extension:signature.value[x].data",
      "path" : "DocumentReference.content.attachment.extension.value[x].data",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.contentType",
      "path" : "DocumentReference.content.attachment.contentType",
      "comment" : "Strukturierte Rechnungsinhalte können seitens der Leistungserbringer:in sowohl als JSON als auch XML übergeben werden.",
      "min" : 1,
      "patternCode" : "application/fhir+json",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.data",
      "path" : "DocumentReference.content.attachment.data",
      "comment" : "Die angereicherte Rechnung wird durch den FD direkt als Binary-Ressource unter attachment.url referenziert.",
      "max" : "0"
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.attachment.url",
      "path" : "DocumentReference.content.attachment.url",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:strukturierterRechnungsinhalt.format",
      "path" : "DocumentReference.content.format",
      "min" : 1,
      "patternCoding" : {
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
        "code" : "rechnungsinhalt"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang",
      "path" : "DocumentReference.content",
      "sliceName" : "anhang",
      "min" : 0,
      "max" : "1",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment",
      "path" : "DocumentReference.content.attachment",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature",
      "path" : "DocumentReference.content.attachment.extension",
      "sliceName" : "signature",
      "comment" : "Die Signatur auf Ebene der Attachment muss vorhanden sein und umfasst eine Signatur über den Hash des Anhangs. Die Extension hat keine Mindestkardinalität von 1, da sie in R5 entfernt wird und die Instanz dann immer noch valide sein muss.",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "Extension",
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-signature"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].type",
      "path" : "DocumentReference.content.attachment.extension.value[x].type",
      "patternCoding" : {
        "system" : "urn:iso-astm:E1762-95:2013",
        "code" : "1.2.840.10065.1.12.1.13"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].when",
      "path" : "DocumentReference.content.attachment.extension.value[x].when",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].who",
      "path" : "DocumentReference.content.attachment.extension.value[x].who",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].who.identifier",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].who.identifier.system",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.system",
      "patternUri" : "urn:ietf:rfc:3986",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].who.identifier.value",
      "path" : "DocumentReference.content.attachment.extension.value[x].who.identifier.value",
      "patternString" : "urn:oid:1.2.276.0.76.4.323",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].targetFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].targetFormat",
      "mustSupport" : true,
      "binding" : {
        "strength" : "required",
        "valueSet" : "https://gematik.de/fhir/dipag/ValueSet/dipag-restricted-mime-types-in-binary-vs"
      }
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].sigFormat",
      "path" : "DocumentReference.content.attachment.extension.value[x].sigFormat",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.extension:signature.value[x].data",
      "path" : "DocumentReference.content.attachment.extension.value[x].data",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.contentType",
      "path" : "DocumentReference.content.attachment.contentType",
      "comment" : "Zum Zeitpunkt der Veröffentlichung werden nur PDF-Dokumente als Rechnungsanhänge seitens der Leistungserbringer:in unterstützt.",
      "min" : 1,
      "patternCode" : "application/pdf",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.data",
      "path" : "DocumentReference.content.attachment.data",
      "comment" : "Die angereicherte Rechnung wird durch den FD direkt als Binary-Ressource unter attachment.url referenziert.",
      "max" : "0"
    },
    {
      "id" : "DocumentReference.content:anhang.attachment.url",
      "path" : "DocumentReference.content.attachment.url",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.content:anhang.format",
      "path" : "DocumentReference.content.format",
      "min" : 1,
      "patternCoding" : {
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
        "code" : "rechnungsanhang"
      },
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.context",
      "path" : "DocumentReference.context",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.context.related",
      "path" : "DocumentReference.context.related",
      "slicing" : {
        "discriminator" : [{
          "type" : "pattern",
          "path" : "type"
        }],
        "rules" : "open"
      },
      "comment" : "Der Fachdienst verknüpft alle Rechnungsdokumente mit der Rechnungsempfänger:in. Die Slices werden über das Element Reference.type unterschieden und NICHT über die Auflösung der Referenz (resolve()), damit eine einzelne DocumentReference auch ohne Bundle-Kontext (z.B. als Ergebnis der $retrieve-Operation oder der Suche) validierbar bleibt. Der Fachdienst MUSS Reference.type entsprechend dem Zieltyp ('Patient' bzw. 'DocumentReference') setzen.",
      "min" : 1,
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.context.related:patient",
      "path" : "DocumentReference.context.related",
      "sliceName" : "patient",
      "min" : 1,
      "max" : "1",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Patient"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.context.related:patient.type",
      "path" : "DocumentReference.context.related.type",
      "min" : 1,
      "patternUri" : "Patient",
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.context.related:anhaenge",
      "path" : "DocumentReference.context.related",
      "sliceName" : "anhaenge",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Reference",
        "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/DocumentReference"]
      }],
      "mustSupport" : true
    },
    {
      "id" : "DocumentReference.context.related:anhaenge.type",
      "path" : "DocumentReference.context.related.type",
      "min" : 1,
      "patternUri" : "DocumentReference",
      "mustSupport" : true
    }]
  }
}

```
