# BeispielNutzungsprotokollResultBundle - Implementierungsleitfaden Digitale Patientenrechnung v1.0.8

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.0.8 - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **BeispielNutzungsprotokollResultBundle**

## Beispiel Bundle: BeispielNutzungsprotokollResultBundle



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BeispielNutzungsprotokollResultBundle",
  "type" : "searchset",
  "total" : 7,
  "link" : [{
    "relation" : "self",
    "url" : "https://example.com/fhir/AuditEvent?agent-display=Max%20Mustermann"
  }],
  "entry" : [{
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollNutzerkontoEinrichten",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollNutzerkontoEinrichten",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollNutzerkontoEinrichten\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollNutzerkontoEinrichten</b></p><a name=\"BeispielNutzungsprotokollNutzerkontoEinrichten\"> </a><a name=\"hcBeispielNutzungsprotokollNutzerkontoEinrichten\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"http://hl7.org/fhir/R4/codesystem-restful-interaction.html#restful-interaction-create\">FHIR Restful Interactions: create</a> (create)</p><p><b>action</b>: Create</p><p><b>recorded</b>: 2024-01-15 10:00:00+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>Allgemein</td><td>Ein Nutzerkonto wurde eingerichtet.</td></tr></table></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "http://hl7.org/fhir/restful-interaction",
        "code" : "create"
      }],
      "action" : "C",
      "recorded" : "2024-01-15T10:00:00.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        },
        "detail" : [{
          "type" : "Allgemein",
          "valueString" : "Ein Nutzerkonto wurde eingerichtet."
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollRetrieve",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollRetrieve",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollRetrieve\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollRetrieve</b></p><a name=\"BeispielNutzungsprotokollRetrieve\"> </a><a name=\"hcBeispielNutzungsprotokollRetrieve\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"CodeSystem-dipag-operationen-cs.html#dipag-operationen-cs-retrieve\">Digitale Patientenrechnung Operationen: retrieve</a> (Digitale Patientenrechnung_Retrieve)</p><p><b>action</b>: Execute</p><p><b>recorded</b>: 2024-05-30 09:15:22+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"DocumentReference-BeispielDocumentReferenceRechnungRetrieve.html\">DocumentReference: extension = 2024-01-10,2024-02-10,120 EUR,Allgemeinmedizin (Aerztliche Fachrichtungen#ALLG),ambulatory (ActCode#AMB); identifier = https://gematik.de/fhir/sid/dipag-token#123-456-789; status = current; type = Rechnung ambulante/stationäre Behandlung; description = Rechnung Reiseimpfung vom 10.01.2024</a></p><p><b>name</b>: Rechnung Reiseimpfung vom 10.01.2024</p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>Allgemein</td><td>Rechnung abgerufen</td></tr></table></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Binary/id-der-originalen-rechnung\">Binary/id-der-originalen-rechnung</a></p><p><b>name</b>: Originale Rechnung zu Rechnung Reiseimpfung vom 10.01.2024</p></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Binary/id-der-angereicherten-rechnung\">Binary/id-der-angereicherten-rechnung</a></p><p><b>name</b>: Angereicherte Rechnung zu Rechnung Reiseimpfung vom 10.01.2024</p></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Binary/id-des-strukturierten-Rechnungsinhalts\">Binary/id-des-strukturierten-Rechnungsinhalts</a></p><p><b>name</b>: Strukturierter Rechnungsinhalt zu Rechnung Reiseimpfung vom 10.01.2024</p></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-operationen-cs",
        "code" : "retrieve"
      }],
      "action" : "E",
      "recorded" : "2024-05-30T09:15:22.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        }
      },
      {
        "what" : {
          "reference" : "DocumentReference/BeispielDocumentReferenceRechnungRetrieve",
          "type" : "DocumentReference"
        },
        "name" : "Rechnung Reiseimpfung vom 10.01.2024",
        "detail" : [{
          "type" : "Allgemein",
          "valueString" : "Rechnung abgerufen"
        }]
      },
      {
        "what" : {
          "reference" : "Binary/id-der-originalen-rechnung",
          "type" : "Binary"
        },
        "name" : "Originale Rechnung zu Rechnung Reiseimpfung vom 10.01.2024"
      },
      {
        "what" : {
          "reference" : "Binary/id-der-angereicherten-rechnung",
          "type" : "Binary"
        },
        "name" : "Angereicherte Rechnung zu Rechnung Reiseimpfung vom 10.01.2024"
      },
      {
        "what" : {
          "reference" : "Binary/id-des-strukturierten-Rechnungsinhalts",
          "type" : "Binary"
        },
        "name" : "Strukturierter Rechnungsinhalt zu Rechnung Reiseimpfung vom 10.01.2024"
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollChangeStatus",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollChangeStatus",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollChangeStatus\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollChangeStatus</b></p><a name=\"BeispielNutzungsprotokollChangeStatus\"> </a><a name=\"hcBeispielNutzungsprotokollChangeStatus\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"CodeSystem-dipag-operationen-cs.html#dipag-operationen-cs-change-status\">Digitale Patientenrechnung Operationen: change-status</a> (Digitale Patientenrechnung_ChangeStatus)</p><p><b>action</b>: Execute</p><p><b>recorded</b>: 2024-05-31 14:30:00+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"DocumentReference-BeispielDocumentReferenceRechnungRetrieve.html\">DocumentReference: extension = 2024-01-10,2024-02-10,120 EUR,Allgemeinmedizin (Aerztliche Fachrichtungen#ALLG),ambulatory (ActCode#AMB); identifier = https://gematik.de/fhir/sid/dipag-token#123-456-789; status = current; type = Rechnung ambulante/stationäre Behandlung; description = Rechnung Reiseimpfung vom 10.01.2024</a></p><p><b>name</b>: Rechnung Reiseimpfung vom 10.01.2024</p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>DocumentReference.meta.tag:dipag-rechnungsstatus</td><td>Rechnungsstatus geändert auf 'Bezahlt'</td></tr></table></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-operationen-cs",
        "code" : "change-status"
      }],
      "action" : "E",
      "recorded" : "2024-05-31T14:30:00.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        }
      },
      {
        "what" : {
          "reference" : "DocumentReference/BeispielDocumentReferenceRechnungRetrieve",
          "type" : "DocumentReference"
        },
        "name" : "Rechnung Reiseimpfung vom 10.01.2024",
        "detail" : [{
          "type" : "DocumentReference.meta.tag:dipag-rechnungsstatus",
          "valueString" : "Rechnungsstatus geändert auf 'Bezahlt'"
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollProcessFlag",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollProcessFlag",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollProcessFlag\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollProcessFlag</b></p><a name=\"BeispielNutzungsprotokollProcessFlag\"> </a><a name=\"hcBeispielNutzungsprotokollProcessFlag\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"CodeSystem-dipag-operationen-cs.html#dipag-operationen-cs-process-flag\">Digitale Patientenrechnung Operationen: process-flag</a> (Digitale Patientenrechnung_ProcessFlag)</p><p><b>action</b>: Execute</p><p><b>recorded</b>: 2024-06-01 10:00:00+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"DocumentReference-BeispielDocumentReferenceRechnungRetrieve.html\">DocumentReference: extension = 2024-01-10,2024-02-10,120 EUR,Allgemeinmedizin (Aerztliche Fachrichtungen#ALLG),ambulatory (ActCode#AMB); identifier = https://gematik.de/fhir/sid/dipag-token#123-456-789; status = current; type = Rechnung ambulante/stationäre Behandlung; description = Rechnung Reiseimpfung vom 10.01.2024</a></p><p><b>name</b>: Rechnung Reiseimpfung vom 10.01.2024</p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>DocumentReference.meta.extension:markierung</td><td>Markierung 'Persönlich' gesetzt</td></tr></table></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-operationen-cs",
        "code" : "process-flag"
      }],
      "action" : "E",
      "recorded" : "2024-06-01T10:00:00.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        }
      },
      {
        "what" : {
          "reference" : "DocumentReference/BeispielDocumentReferenceRechnungRetrieve",
          "type" : "DocumentReference"
        },
        "name" : "Rechnung Reiseimpfung vom 10.01.2024",
        "detail" : [{
          "type" : "DocumentReference.meta.extension:markierung",
          "valueString" : "Markierung 'Persönlich' gesetzt"
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollEinreichenFrontend",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollEinreichenFrontend",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollEinreichenFrontend\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollEinreichenFrontend</b></p><a name=\"BeispielNutzungsprotokollEinreichenFrontend\"> </a><a name=\"hcBeispielNutzungsprotokollEinreichenFrontend\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"CodeSystem-dipag-operationen-cs.html#dipag-operationen-cs-process-flag\">Digitale Patientenrechnung Operationen: process-flag</a> (Digitale Patientenrechnung_ProcessFlag)</p><p><b>action</b>: Execute</p><p><b>recorded</b>: 2024-06-03 08:20:00+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p></blockquote><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"DocumentReference-BeispielDocumentReferenceRechnungRetrieve.html\">DocumentReference: extension = 2024-01-10,2024-02-10,120 EUR,Allgemeinmedizin (Aerztliche Fachrichtungen#ALLG),ambulatory (ActCode#AMB); identifier = https://gematik.de/fhir/sid/dipag-token#123-456-789; status = current; type = Rechnung ambulante/stationäre Behandlung; description = Rechnung Reiseimpfung vom 10.01.2024</a></p><p><b>name</b>: Rechnung Reiseimpfung vom 10.01.2024</p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>DocumentReference.meta.extension:markierung</td><td>Die Rechnung wurde über das Frontend eingereicht.</td></tr></table></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-operationen-cs",
        "code" : "process-flag"
      }],
      "action" : "E",
      "recorded" : "2024-06-03T08:20:00.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        }
      },
      {
        "what" : {
          "reference" : "DocumentReference/BeispielDocumentReferenceRechnungRetrieve",
          "type" : "DocumentReference"
        },
        "name" : "Rechnung Reiseimpfung vom 10.01.2024",
        "detail" : [{
          "type" : "DocumentReference.meta.extension:markierung",
          "valueString" : "Die Rechnung wurde über das Frontend eingereicht."
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollBerechtigungBestaetigen",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollBerechtigungBestaetigen",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollBerechtigungBestaetigen\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollBerechtigungBestaetigen</b></p><a name=\"BeispielNutzungsprotokollBerechtigungBestaetigen\"> </a><a name=\"hcBeispielNutzungsprotokollBerechtigungBestaetigen\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"http://hl7.org/fhir/R4/codesystem-restful-interaction.html#restful-interaction-update\">FHIR Restful Interactions: update</a> (update)</p><p><b>action</b>: Update</p><p><b>recorded</b>: 2024-05-21 10:30:00+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>Rechnungsversand-Berechtigung</td><td>Die Berechtigungsregel zum Rechnungsversand für Zahnarztpraxis Müller wurde durch den Rechnungsempfänger bestätigt.</td></tr></table></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "http://hl7.org/fhir/restful-interaction",
        "code" : "update"
      }],
      "action" : "U",
      "recorded" : "2024-05-21T10:30:00.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        },
        "detail" : [{
          "type" : "Rechnungsversand-Berechtigung",
          "valueString" : "Die Berechtigungsregel zum Rechnungsversand für Zahnarztpraxis Müller wurde durch den Rechnungsempfänger bestätigt."
        }]
      }]
    },
    "search" : {
      "mode" : "match"
    }
  },
  {
    "fullUrl" : "https://example.com/fhir/AuditEvent/BeispielNutzungsprotokollErase",
    "resource" : {
      "resourceType" : "AuditEvent",
      "id" : "BeispielNutzungsprotokollErase",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-nutzungsprotokoll"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"AuditEvent_BeispielNutzungsprotokollErase\"> </a><p class=\"res-header-id\"><b>Generated Narrative: AuditEvent BeispielNutzungsprotokollErase</b></p><a name=\"BeispielNutzungsprotokollErase\"> </a><a name=\"hcBeispielNutzungsprotokollErase\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-nutzungsprotokoll.html\">Digitale Patientenrechnung Nutzungsprotokoll</a></p></div><p><b>type</b>: <a href=\"http://terminology.hl7.org/7.2.0/CodeSystem-audit-event-type.html#audit-event-type-rest\">Audit Event ID: rest</a> (RESTful Operation)</p><p><b>subtype</b>: <a href=\"CodeSystem-dipag-operationen-cs.html#dipag-operationen-cs-erase\">Digitale Patientenrechnung Operationen: erase</a> (Digitale Patientenrechnung_Erase)</p><p><b>action</b>: Execute</p><p><b>recorded</b>: 2024-06-02 16:45:00+0000</p><p><b>outcome</b>: Success</p><h3>Agents</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Who</b></td><td><b>Requestor</b></td></tr><tr><td style=\"display: none\">*</td><td><span title=\"Codes:{http://terminology.hl7.org/CodeSystem/extra-security-role-type humanuser}\">Human User</span></td><td>Max Mustermann (Identifier: NamingSystemKVID/A123456789)</td><td>true</td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Observer</b></td></tr><tr><td style=\"display: none\">*</td><td>DiPag FD Server (Identifier: <a href=\"http://terminology.hl7.org/7.2.0/NamingSystem-uri.html\" title=\"As defined by RFC 3986 (http://www.ietf.org/rfc/rfc3986.txt)(with many schemes defined in many RFCs). For OIDs and UUIDs, use the URN form (urn:oid:(note: lowercase) and urn:uuid:). See http://www.ietf.org/rfc/rfc3001.txt and http://www.ietf.org/rfc/rfc4122.txt \r\n\r\nThis oid is used as an identifier II.root to indicate the the extension is an absolute URI (technically, an IRI). Typically, this is used for OIDs and GUIDs. Note that when this OID is used with OIDs and GUIDs, the II.extension should start with urn:oid or urn:uuid: \r\n\r\nNote that this OID is created to aid with interconversion between CDA and FHIR - FHIR uses urn:ietf:rfc:3986 as equivalent to this OID. URIs as identifiers appear more commonly in FHIR.\r\n\r\nThis OID may also be used in CD.codeSystem.\">Uniform Resource Identifier (URI)</a>/urn:oid:1.2.276.0.76.4.323)</td></tr></table><blockquote><p><b>entity</b></p><p><b>what</b>: <a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/Patient/NutzerkontoPatient\">Patient/NutzerkontoPatient</a></p></blockquote><blockquote><p><b>entity</b></p><p><b>name</b>: Rechnung Reiseimpfung vom 10.01.2024</p><h3>Details</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Type</b></td><td><b>Value[x]</b></td></tr><tr><td style=\"display: none\">*</td><td>Allgemein</td><td>Rechnung gelöscht</td></tr></table></blockquote><blockquote><p><b>entity</b></p><p><b>name</b>: Originale Rechnung zu Rechnung Reiseimpfung vom 10.01.2024</p></blockquote><blockquote><p><b>entity</b></p><p><b>name</b>: Angereicherte Rechnung zu Rechnung Reiseimpfung vom 10.01.2024</p></blockquote><blockquote><p><b>entity</b></p><p><b>name</b>: Strukturierter Rechnungsinhalt zu Rechnung Reiseimpfung vom 10.01.2024</p></blockquote></div>"
      },
      "type" : {
        "system" : "http://terminology.hl7.org/CodeSystem/audit-event-type",
        "code" : "rest"
      },
      "subtype" : [{
        "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-operationen-cs",
        "code" : "erase"
      }],
      "action" : "E",
      "recorded" : "2024-06-02T16:45:00.000000+00:00",
      "outcome" : "0",
      "agent" : [{
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/extra-security-role-type",
            "code" : "humanuser"
          }]
        },
        "who" : {
          "identifier" : {
            "system" : "http://fhir.de/sid/gkv/kvid-10",
            "value" : "A123456789"
          },
          "display" : "Max Mustermann"
        },
        "requestor" : true
      }],
      "source" : {
        "observer" : {
          "identifier" : {
            "system" : "urn:ietf:rfc:3986",
            "value" : "urn:oid:1.2.276.0.76.4.323"
          },
          "display" : "DiPag FD Server"
        }
      },
      "entity" : [{
        "what" : {
          "reference" : "Patient/NutzerkontoPatient",
          "type" : "Patient"
        }
      },
      {
        "name" : "Rechnung Reiseimpfung vom 10.01.2024",
        "detail" : [{
          "type" : "Allgemein",
          "valueString" : "Rechnung gelöscht"
        }]
      },
      {
        "name" : "Originale Rechnung zu Rechnung Reiseimpfung vom 10.01.2024"
      },
      {
        "name" : "Angereicherte Rechnung zu Rechnung Reiseimpfung vom 10.01.2024"
      },
      {
        "name" : "Strukturierter Rechnungsinhalt zu Rechnung Reiseimpfung vom 10.01.2024"
      }]
    },
    "search" : {
      "mode" : "match"
    }
  }]
}

```
