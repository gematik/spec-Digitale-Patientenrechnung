# Beispiel Patient - Implementierungsleitfaden Digitale Patientenrechnung v1.0.8

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.0.8 - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **Beispiel Patient**

## Beispiel Patient: Beispiel Patient

Profile: [DiPagPatient](StructureDefinition-dipag-patient.md)

Max Mustermann(official) Male, DoB: 1980-05-15 ( Krankenversichertennummer)

-------

| | |
| :--- | :--- |
| Contact Detail | * Musterstraße 42 Berlin 10115 DE (home)
* Postfach 123456 Berlin 10115 DE 
 |



## Resource Content

```json
{
  "resourceType" : "Patient",
  "id" : "8e2b7c2a-4f3a-4e7a-9c1a-2d6b8f7e1a3c",
  "meta" : {
    "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-patient"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
        "code" : "KVZ10"
      }]
    },
    "system" : "http://fhir.de/sid/gkv/kvid-10",
    "value" : "K123456789",
    "assigner" : {
      "identifier" : {
        "type" : {
          "coding" : [{
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "XX"
          }]
        },
        "system" : "http://fhir.de/sid/arge-ik/iknr",
        "value" : "109500969"
      }
    }
  }],
  "name" : [{
    "use" : "official",
    "text" : "Max Mustermann",
    "family" : "Mustermann",
    "given" : ["Max"]
  }],
  "gender" : "male",
  "birthDate" : "1980-05-15",
  "address" : [{
    "use" : "home",
    "type" : "both",
    "line" : ["Musterstraße 42"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Musterstraße"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "42"
      }]
    }],
    "city" : "Berlin",
    "postalCode" : "10115",
    "country" : "DE"
  },
  {
    "type" : "postal",
    "line" : ["Postfach 123456"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-postBox",
        "valueString" : "123456"
      }]
    }],
    "city" : "Berlin",
    "postalCode" : "10115",
    "country" : "DE"
  }]
}

```
