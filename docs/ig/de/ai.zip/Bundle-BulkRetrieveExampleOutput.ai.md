# BulkRetrieveExampleOutput - Implementierungsleitfaden Digitale Patientenrechnung v1.0.8

Implementierungsleitfaden Digitale Patientenrechnung

Version 1.0.8 - ci-build 

* [**Table of Contents**](toc.md)
* [**Artefaktübersicht**](artifacts.md)
* **BulkRetrieveExampleOutput**

## Beispiel Bundle: BulkRetrieveExampleOutput



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BulkRetrieveExampleOutput",
  "type" : "batch-response",
  "entry" : [{
    "fullUrl" : "urn:uuid:f47ac10b-58cc-4372-a567-0e02b2c3d479",
    "resource" : {
      "resourceType" : "Parameters",
      "id" : "BeispielParameterRetrieveOutput",
      "parameter" : [{
        "name" : "dokument",
        "resource" : {
          "resourceType" : "DocumentReference",
          "id" : "BeispielDocumentReferenceRechnungRetrieve",
          "meta" : {
            "extension" : [{
              "extension" : [{
                "url" : "markierung",
                "valueCoding" : {
                  "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-rechnung-markierung-cs",
                  "code" : "eingereicht-frontend",
                  "display" : "Eingereicht (per Frontend)"
                }
              },
              {
                "url" : "zeitpunkt",
                "valueDateTime" : "2024-01-15T10:00:00Z"
              }],
              "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-markierung"
            }],
            "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-dokumentenmetadaten-intern"],
            "tag" : [{
              "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-rechnungsstatus-cs",
              "code" : "offen",
              "display" : "Offen"
            }]
          },
          "extension" : [{
            "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-rechnungsdatum",
            "valueDateTime" : "2024-01-10"
          },
          {
            "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-zahlungsziel",
            "valueDate" : "2024-02-10"
          },
          {
            "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-documentreference-gesamtbetrag",
            "valueMoney" : {
              "value" : 120,
              "currency" : "EUR"
            }
          },
          {
            "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-docref-fachrichtung",
            "valueCoding" : {
              "system" : "http://ihe-d.de/CodeSystems/AerztlicheFachrichtungen",
              "code" : "ALLG",
              "display" : "Allgemeinmedizin"
            }
          },
          {
            "url" : "https://gematik.de/fhir/dipag/StructureDefinition/dipag-behandlungsart",
            "valueCoding" : {
              "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
              "code" : "AMB"
            }
          }],
          "identifier" : [{
            "system" : "https://gematik.de/fhir/sid/dipag-token",
            "value" : "123-456-789"
          }],
          "status" : "current",
          "type" : {
            "coding" : [{
              "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
              "code" : "AM010106",
              "display" : "Rechnung ambulante/stationäre Behandlung"
            }]
          },
          "subject" : {
            "display" : "Max Mustermann"
          },
          "description" : "Rechnung Reiseimpfung vom 10.01.2024",
          "content" : [{
            "attachment" : {
              "contentType" : "application/pdf",
              "url" : "[FD-endpunkt]/Binary/id-der-originalen-rechnung"
            },
            "format" : {
              "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
              "code" : "originaleRechnung"
            }
          },
          {
            "attachment" : {
              "contentType" : "application/pdf",
              "url" : "[FD-endpunkt]/Binary/id-der-angereicherten-rechnung"
            },
            "format" : {
              "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
              "code" : "angereichertesPDF"
            }
          },
          {
            "attachment" : {
              "contentType" : "application/fhir+json",
              "url" : "[FD-endpunkt]/Binary/id-des-strukturierten-Rechnungsinhalts"
            },
            "format" : {
              "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
              "code" : "rechnungsinhalt"
            }
          }]
        }
      },
      {
        "name" : "dokument.pdf",
        "resource" : {
          "resourceType" : "Binary",
          "id" : "BeispielBinarySubmitOutput3-FD",
          "contentType" : "application/pdf",
          "data" : "JVBERi0xLjcNCiW1tbW1DQoxIDAgb2JqDQo8PC9UeXBlL0NhdGFsb2cvUGFnZXMgMiAwIFIvTGFuZyhkZSkgL1N0cnVjdFRyZWVSb290IDEwIDAgUi9NYXJrSW5mbzw8L01hcmtlZCB0cnVlPj4vTWV0YWRhdGEgMjAgMCBSL1ZpZXdlclByZWZlcmVuY2VzIDIxIDAgUj4+DQplbmRvYmoNCjIgMCBvYmoNCjw8L1R5cGUvUGFnZXMvQ291bnQgMS9LaWRzWyAzIDAgUl0gPj4NCmVuZG9iag0KMyAwIG9iag0KPDwvVHlwZS9QYWdlL1BhcmVudCAyIDAgUi9SZXNvdXJjZXM8PC9Gb250PDwvRjEgNSAwIFI+Pi9FeHRHU3RhdGU8PC9HUzcgNyAwIFIvR1M4IDggMCBSPj4vUHJvY1NldFsvUERGL1RleHQvSW1hZ2VCL0ltYWdlQy9JbWFnZUldID4+L01lZGlhQm94WyAwIDAgNTk1LjMyIDg0MS45Ml0gL0NvbnRlbnRzIDQgMCBSL0dyb3VwPDwvVHlwZS9Hcm91cC9TL1RyYW5zcGFyZW5jeS9DUy9EZXZpY2VSR0I+Pi9UYWJzL1MvU3RydWN0UGFyZW50cyAwPj4NCmVuZG9iag0KNCAwIG9iag0KPDwvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAxNDg+Pg0Kc3RyZWFtDQp4nC2MSwuCQBhF9x98/+EuNWheKTOCuPCRFLkIB1xECyFzlfT4/9AY3c3lwOFA9s9xQZ7LrjrUUPI0LjOi27Stm7goUNYVXkxKqHXOWQ2FNEvFzsAlWmQG74lp2GBhKj2T3GtoA39nWlUFDauEMwlsmoWHfwSp7S3mT+hi/pH7U8t0iRBf4Y9MTcidmdB0Fb4CZiJ1DQplbmRzdHJlYW0NCmVuZG9iag0KNSAwIG9iag0KPDwvVHlwZS9Gb250L1N1YnR5cGUvVHJ1ZVR5cGUvTmFtZS9GMS9CYXNlRm9udC9CQ0RFRUUrQXB0b3MvRW5jb2RpbmcvV2luQW5zaUVuY29kaW5nL0ZvbnREZXNjcmlwdG9yIDYgMCBSL0ZpcnN0Q2hhciAzMi9MYXN0Q2hhciAzMi9XaWR0aHMgMTggMCBSPj4NCmVuZG9iag0KNiAwIG9iag0KPDwvVHlwZS9Gb250RGVzY3JpcHRvci9Gb250TmFtZS9CQ0RFRUUrQXB0b3MvRmxhZ3MgMzIvSXRhbGljQW5nbGUgMC9Bc2NlbnQgOTM5L0Rlc2NlbnQgLTI4Mi9DYXBIZWlnaHQgOTM5L0F2Z1dpZHRoIDU2MS9NYXhXaWR0aCAxNjgyL0ZvbnRXZWlnaHQgNDAwL1hIZWlnaHQgMjUwL1N0ZW1WIDU2L0ZvbnRCQm94WyAtNTAwIC0yODIgMTE4MiA5MzldIC9Gb250RmlsZTIgMTkgMCBSPj4NCmVuZG9iag0KNyAwIG9iag0KPDwvVHlwZS9FeHRHU3RhdGUvQk0vTm9ybWFsL2NhIDE+Pg0KZW5kb2JqDQo4IDAgb2JqDQo8PC9UeXBlL0V4dEdTdGF0ZS9CTS9Ob3JtYWwvQ0EgMT4+DQplbmRvYmoNCjkgMCBvYmoNCjw8L0F1dGhvcij+/wBTAGMAaAD2AG4ALAAgAEoAbwBuAGEAcykgL0NyZWF0b3Io/v8ATQBpAGMAcgBvAHMAbwBmAHQArgAgAFcAbwByAGQAIABmAPwAcgAgAE0AaQBjAHIAbwBzAG8AZgB0ACAAMwA2ADUpIC9DcmVhdGlvbkRhdGUoRDoyMDI2MDIyNzE0MTczOCswMScwMCcpIC9Nb2REYXRlKEQ6MjAyNjAyMjcxNDE3MzgrMDEnMDAnKSAvUHJvZHVjZXIo/v8ATQBpAGMAcgBvAHMAbwBmAHQArgAgAFcAbwByAGQAIABmAPwAcgAgAE0AaQBjAHIAbwBzAG8AZgB0ACAAMwA2ADUpID4+DQplbmRvYmoNCjE3IDAgb2JqDQo8PC9UeXBlL09ialN0bS9OIDcvRmlyc3QgNDYvRmlsdGVyL0ZsYXRlRGVjb2RlL0xlbmd0aCAzMjA+Pg0Kc3RyZWFtDQp4nG1SXYvCMBB8F/wP+w+2OVsPQQTxAw+xlFa4B/Eh1r222CaSpqD//rJtD3vgS5jZzEx2k4gAPBA+BAKEA14AwqHZFMQH+J8OTsCf+SCmEHgzmM8xYrUHMSYY4fF5J0ysaVK7KanC/Qm8M2CUwYQ1i8V41Fm83rLWaVORsu+cgluJz9C7BoqjIYq1thjrkg7yzj1yXiSNy+JdbpcrHON3MYPdkB52T08QffTWZSltCUNeNur6IkcnvegHJpRa3JG8kukwe/7wlyoLRUkuuUMuLJVLkLbQqufGFj/SgZZ9a3O7aH17Tc+VOiey3KTFg0yNHvBV7tYBXxey1NmgkJTFtT+61XbQyTIjK9wWWWPcKIUtCXcCV7riU5cqzbWb4C5VO2vduvorCZuqPvFXmP57hFBWVJ86+nqh8egXVT+wqQ0KZW5kc3RyZWFtDQplbmRvYmoNCjE4IDAgb2JqDQpbIDIwM10gDQplbmRvYmoNCjE5IDAgb2JqDQo8PC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDY4NTYvTGVuZ3RoMSAxOTg0MD4+DQpzdHJlYW0NCnic7XwLdBvXeeZ/ZwYg+BSotwXJGAgiLBkkSJEiLZKyApEiZepJkZQESJbNITAkIOElPEjRthIlrm0VrZ1sfXY38Tab2u1p2nUSD+3GkdytaydxepqukmbPtmnzaJpttmnO6Xq7qZNNHVnY794ZgCCtOD05J/VJyxnMP/f+97//+/53BoJIjIhWASgUPDbe3nnwnz5uJ2IXgZ0cn9g38ZUbXy4RHeT9hyJJLVO/1/EK0bor6J+LzOZVz0fXfYHoDt5/ZTozkzz1K6ucGH8DTB+eScxPv9Hxxm6i7fcQyV+M6Vp02zM/eAq0N3D1xIBouNH4O5C3C/1tsWT+YkudbSf6f0G0xkikI1qkJ/owUetaojpnUruYcSRX/SPGQ6BXk3pe6/nNi+NEI3ngpJSW1NedX/NPYL0N89sy6Vy+9DHqxPgEp89k9UzmkdIaohbYI60ibrskffDy3+1/9P5Ve35A9Q7ixzd/q/Amv//PWGf3DfbW9dqCA/LJThKZB+bVPPzWH0In3w32o+9jnJYeylc4ja2GAvDrKpIx00ntjCt5eNXD6DFSlIfYh8hGDluXch1TnjLv0nWalr6Oez0pEj8UlaTHMC6XeR8ZV1V6hRrfumHq4FgrdanEPsbH5C/ZBrilJMuvQYvPkINftHK8K4d9jIx3W4eV4xfrUB6ic++2DivHTz+kT9LT77YO/5YOOU3j77YOK8fKsXKsHCvHyrFyrBzsN/75tFKIPvlzU+TnfEg/oEffbR1WjpXjX+5gf/0uCOXfLvJv+dYCMnFX6CTuTpwcv5X20RGKUpb+C71aKhH/nm8ZpvQKZhXpb1ldaR94OJcKkP9S/o6yhih48CMf/o//4bFHH/mlhz/w/svve++lhx58YP7i3Gwhn8teyKRTycT5c/HYzLQejUxpk/ffd/beM6fDoVMnT0yMHx89dvTI4UMHR+45MLzd7ayrbWUL9XWD3kG9rq2VFurq0axva2WGfdCoEUjjmF81gsdDnkNjoaH9Lo8n7PJ6jKChtAzxS4sWI+WBMFhgFuaCxaFx76Hjp0PqUHFSDAIzsaRnju+ujFktQxqcCBnDfvSq+gdEv9K9Z9nwSHnYqxo0WixGF0huAT7oWmCiYRv8lTAsCXuNKb/X4w3poF1wUINnYnIQrYZyi6kHwFG96qQpXJFT3qvMap0OGerkdPgeUJPUYojP+FXq9l4025OGGlFVw97inRoNFT0Gm/S6rP5YCB5jmqvo8XrUcPhq6dXNnNrrAS+JBha87MrxhSC7Mn46dA0hV69MhJ6XmDQ4ORBe2Iax0DUVQRdYiWM5kndU3qFDDJF5XnIIete1INFlMaoIhOhHYIXAOco4RpGrkolzmoJ8QlAQWRy5qpgjwTK1ApzDxF02qbdb1A6MOPnISyQh58WgecBLiEywzhZ0BGuDDVKjhFhw1PPAvATaWkYvNLBG5loAzzGBvsouL9QGXdcEpzGL8jIoOe5yBQfNOVkVI8gzDT+xaMGJ06EXGgj8BQTFAD/aWocWpKN+72JaHw8hekML7Kh/EqnNu3LLkIq0NoLjIU476ULOI7v3t7Xy7FJDXt3lDS+sXVvMDC04nYOHioNIZOSaSLAFze6b9BfNlOOJ5nX2IU3llpGId3gSJF4sG3xGgIqcVCeNqUk/mqpzuDjMs0Lj1LR+QZJbFpjSwvbSXvjN3mDUefUBo947UBl5D73HHLHzkRrvgMHWm14f8g6pG+PFiHcKGRgcDc24psMaeBtBr2Yo3gHXgkIDWC8bGUwaWqCjfth2CDl4zD96BouUO0MtFverC0HFp0U03t/vwbovWkPe/fvDVTOG1KIR1CKToBgKC2KsRCCHvJoahZdhLjw37kXz9Gk+Z+J0qNgQ9Ua98HAwWNRgtkuNhF3FcER4HPOhGrW12hark1WcJL7mWyLTAFdVmpr0TpkIvjqX42aWI6ZBVY3zHuTixJ2Je/GgdygKCn5pUUNGxnnUaNhMGRoVdeMnErEqIhUxFcyLzv5yj1k9dPApGjNLu7FKd5hfk/BawMwVQ/HxzAt5jHMuIxH2V0g04/KUWlSd3j4vB2LyAX5NGjY0Lkc0XpzsPPeAOAiEGppCLoPh8GSxnHGYpvgqkoyUfwlLlFQ2AdFSCzfHuDyqTobVyUlgsXo8LtWw4a5Oazy5eNkdNe0ZRe3HTSuOYy7xBeQyarADTGu614NqbfBFa3qf66hAOxoPGeQqFr1Fg0HFlmEQg73PsPtG+A2fjN+r6Qgil6dqupg7DHWFdzg315DXEwaJ1CJ8CcehWkxxECkiG42zWG22lubi6qLaW0TVOouCq/giJyexLahOdVgVodaQydwJI7wXBiOTsLaFE2K++PiMpH/hbE3LIkZ80n6T2CG4QrOxkDFaJqkRHzQu+A1pw24McuPZGOqHIgLFnWdrGYF7g8gqF5+tGtJEyAqPmD/Cp7rKATOnASPKLt8WPWV96019TaF28WkQn9oWw9GCQBsKdDCHa7g5i0mANpQ258hCXdMAtCFKtUaEIZNWR2nRhU3mdqjy8okHBc3LL9fV0iujqJGTXn6Fw1y8QwjiMwTrosmYu8vOB2/lCkuS+annnxFhQjW6TnxqhM58zDTJttTxlveu4YHL9JzHOnjOcCsfs1alte50lxEL+6PmLLtVwVVUVFTuyHHxtHEGq8HrqUEdg/lYVaox7scmImx7zPTqQbM68Kxkw14aRg5ZDVpPBnnvYRwQlpb3HkNCt9LyPi8Rc3h381utd/eCxGpQ7XkxcjY2oNAXI5NRc6OGl2m3aw9/NLKLQNeK2M7y0jQRsrmUsEgZnzHnt7LYhLP+yvgcX5M1ZU86+FixMmgT7ObM3PBZcNbvuOWsouOfJ8xhRdOoFWO8Gvkc7yxKNgN00AzXQcnkfNCsE8D6IsUiL20LZ5v4Cm3wNQO/Gqr1QsleS0v45iGoMspFOwRGdLHcarg6Ztha6jHgBO2rZmrXY9AJbV51mVT4XMPD+6y/TG06AXrXtZh5bg1bs83snPOH0Rrm1yRIhvllraR6a5U2LKv6FnszprVLB70VZnyj91Y48t4Ca8AzsOKyQaJPdcJdfcKfPqiKfrFvgdX4LAIbJ5Ba+orF+nL95+X/Gh5ASTxcUri4HGFcQjwQ68ZbjziWYxsF2opyY+XOkdZyqBs06gf58wvfm2p5AgQQ30uvWTVHPE5UOUag+FKsxm7kvq8pl4S0vzy37LdpsaStucuwE6FLwHJPvcZ3EoPhbvN5+OXirhPSeI6n/daD7iUe3Q8Idh/wq2ocz1mDDE9b2CjjfKtSObXDJ4pcEQ88cU0TdUi8xmzEs9QYfzrGG4DXqbI9tMd8GfJa7xnYA5SW0B5XbxjvFVdL39scNkuVhE0e10RRVZ3NGCqqq/GiYTwi3GuNeQUOu7jdZ1FxCx7B4jTpuPYNUvHQOJzA38jqdrvq+Fte+QXrw/53Glb5fFQp437vRQ93hXHSO4+HhUGvoar3oiQCeWBzuFjEdlr08jepkyET8iHWupk/GfCnGIvWtRnvaIvdhs083bSrpRc289elirQHy9KykMYbxbI4I3JLaTzL2Bkz1/AR6i/0kNeUr/gsocV7i6fxfugxtnDBlh7oNm0OCw7Q5MNcEwqW7u8oue/bWXKfbc+6721/0n2mveQ+HSi5w4Hr7lBryX2qreQ+2XbdfcJfck/sOOge31Fyj91Zch+/81n36A7VfWz7kPvo9mfdR7aX3IfvKLkP+Urugz6/e2TbjPuebdfdB7aV3MMtJfdQy7Pu/d6Se3BryT3gue7e5ym5g55n3e9Rr7v3qiX33eqT7j1qu7v/9qy77/aSu9ddcu92X3bftSXr7tlScndvue7etfm6u2tzyd25+Vn3zo6sO9B6t7utNeu+c8d97hbI2rbJddu93q1B91Z50233ejbd7Vb3oOG+fcZ9+46N6+/dsqHk3ry+5HZ139Z3ZmPP+r4zm4KjvL2Bt9fd1r8+dnpN7+oTzb3OE6vDznBjb8MJW690QsHVEF7V03SivrfuRE2v/URTuC5sD1O4ttdxQsaoIyyFnSQHgzZ2jX2IJvyHrtaUxg4ZjtEzBrtitIxziNcGw37FoBOnz4QWGHsi/Mjjj9OWgUPGh8ZDz8uEJp4kpcHjoQVFfiI8QH7y+/1knaJp9f1+VnUSLv4hv9kwxy1yq13p+MukFn7JyEayDfCTVpf+rPRd+e+pmaj0evm6+VTpf9s20GqzTw/R+ymJc46iOHn7AcrQLI2TTgVK0AwozgPm6Bx9lTQ6TVmaAMUMPQjqRymGGbOAF9D/JZqkNDg9SEcwPyQ4aKBMYHQW3C8JTpx+DL04Rh8GzxPgGQU2S8fpFJ0FxQU8OvBvmF6zHSSZVtEaaqP24KY7N6ib7rBtU+rWxusUpzOwZduaNUzKkiML4zudX+hs7gLwN6/e0Nux80Kzp7llq697V09X5/p1a+02T7OH+Xru6unp3uXzbrWv85ZHauz2Gvm1m7dt6+jYtq2z8+Y+ee+NzzJd6e/v6xk7OXF/5pn3f+A/jQ7etVWxHXzzxW+1b9vWzq9fVz5744dj59taD/T0HwuNXrry0PnR6C7/oW7+3ZsDz/HPIQI1VEeuYGOd4rDbCboqQlno2Nve1Qwtc6yLeWWPvMYjO9iPXmb/96XLb/33Rz/Dvvgd28CbL7P5m49JTul9hB1bcLR/zu7j3+Yxu/JlH56oX5TqGWMXT5J/F/8doUFkexpSV5E76JRrG+WGBjvZIdZhie1sXt3bzr2Ta4Zc1tXste7Ga+xbI+zPX1nYe/Ou2Zsde20DN74r3/bmy8onbvxYtv14gtt0rvS6/A2eVeSmLUFnU122kbKb6h012TVOquf8O/nH37FzaKuPO577d0MzhNxht9/R2XNXs084fu169vrcp+7Xr16KPdX+8f9cu+u3jpx/onXHI/ojj71vdfZvPv7bf3XhzFGp4c2XnzgQ/mX9AJsbO//yc59+GfY9DTWuyF+jJloXrK+V7TVZZs9SHQ8/JAurNkBq1zqIsdc0P/1R+45fK6zdMJIaU+Uv/fbh6Y/4BlvfEraMS23Sj20TtJl8sKVR3bLF41jl2ChvooY11N71+c4Nvc1dyKeOnfssW+5akjbr11Ws6rYLkw4OXNj/8OvP3HfP4eknX/zgqQ+eeLxm1+Pto+/1/MlzI1LbrpnD589vl3pO7T9wrPhgIBd/6/8l795/4dh7HpcPHe8bgEafLP2QPQvv1tI6WhOsJaezTonXrea2dXE9xn1SN3y5VqqRq7L6LeeG5zY0t+8eGdndc+AA+2ietTzJs+bJm1/L3QyPdPcMD/d0j3CLH5UTUlrwX0NNn65T6FyTAkv9cNs+WNjdxVeCp9Ji32tY9XRT482jDc5nVtXLifuNc2fPnv/EVPlOjP217UU5Yv8cVmjdC8TOEbUj9PvWdGHks6/eLNleZI03/1F8VXw/XaGnfqHPP145b32yun+FZ/sv6Hlx5Vw5V86V8+d0/s7P9fzKyvmunP/rX/bE86CPfUn8JoG/4+0mstqMbOgx69cLNfIFqy1X4ZWqto2a5YtW216Fr6HeSruRfV7+ZavdRH7bEavtrKJvXpTFFLLbLJ7MRjbbe612bRVNPzXYHrbae0D/Qf4LC6UWSmRs/95qM6prsFltiZoa5qy2XIVXqto22trwiNW2V+FrKFtpO2i17Tetdi1tbvi41a6niYbPWe0G6mjcYLUb5SuNB6x2E510ftlqO6v4Ny/qBtsbmlusto3qmnda7doqmn7a2NxvtfeAfvx31c6Ozl3qkXgkm86lp/PqYDqbSWe1fDydCqj7Egl1LD4Ty+fUMT2nZ2f1aECdiOnq1vN6NrVVzWtTCV1NT6v5WDynTqdTeXVOy6lRfVZPpDN6VI2n1IyWzauFXDw1o2pqLl+IzqtT8+q+VDT7hDpciMRyajqF+bqa1RP6rJaKCIacP5+S0eLZnLo9ls9ncn3t7TPxfKwwFYikk+0aOOht05xDu0XdJqjbpxLpqfaklsvr2fbDI4NDR8eHAsnojgBsy8xnuTkwemdvtQ4BdVTPJuO5HMxWYUpMz+rQciarpfJ6tFWdzupCrUhMy87orWo+rWqpeTWjZ3OYkJ7Ka/GUaWEEMioe4R6d07I6iKOqlsulI3EN/NRoOlJI6qm8cLM6HU/osJH7YOu4NWPrDiEkqmsJ7kQ+Vh5S5+CEdCEPh+Xy2XiE82gFUSRRiHIdysOJeDJuSRDuNeMIpoUcLOB6tqrJdDQ+ze+6MCtTmErEc7FWNRrnrKcKeSBzHBnRU3wW7GhPZ9WcjsQAhzj0FrYuaidouJQMd2jecpGQOxdLJ5dawpOmgNDlYrqYE03DZULiOT2S5xhOPp1OJNJz3LRIOhWNc4tyfSINtan0rC5MMcOaSuehqakB939mMajWUC6mQfUp3fKXmaJalTVZLj2XR9zjcD2WghC33MrAvkw+neP6a2o+q0X1pJY9XyZaXEwz2XQhI/ImncxoKQgIjOkzhYSWPQm3cLU6Ax07+4919XQvTsoVMplEHJrx9RRQw+mCmtTmedSqlhlcE8nqGo8PYpVJaPOm4zPZOEbhpzzSCylnhYEnHfKZa2fFUsXqSAp7rca0mRdvsyGTTUcLkTyigvWPua18TlkAnDcXi0diywpA2bmL2qdTiXl1e3yHqien9GgVOTi8k7aCXKR1VbbnlkSvwqtfeGB7HFLyepJXsWwcUqPpuVQirUWXek8zXaVnuTlpiAIs5DNYN6hePFNAE9MTmaUeRUnEsjfJeUB4jmXTsfhUHDoHylUKyzsXSJY9KKpVfj6TRjXJxObbkbSF/CmdJ+ypeDQfO5ZBZiLXxuMP6CN5DfGh3yWVOqkD1y60jlCcIpSlNOVwTVMeuEG0spQRUAMmjlaKAuJHgAmcKo0BN0MxjOVET8ddB/UsYFRQTmBUx30rnRcjKbRU0Gs0BQ58hEvjmBh4cS7TQgqXPwcqjomCjnNMYCQjOKugTQFmQJEVtAVQctwM2hquHLAFUM6jPSXgPozyHy5+D+1hjEUgMSfkpyz5XJuskMPlacBHqjQs61+WwmXHgeE8tgsf5IHLUR+145zBGOdZgPQA+KQpCaxm6aBTG3iWdWhfxrutine78FMasB0cNGEXp22nwzSCCA3RURoHDGA0SjuEzweFn+ZBVY6OGemd1PsT/cDnjQrOSRGHnBVt1YpKTIzpli9nREakhC5RahVR46OL3uJceWxmgGsV/k2LyKTE/IzglrMkcOvywuLUkhhGLDveniPlHJ0TMnSLc1Tcc2I0AkrN0o9nEMcUYJsutF7MZq55XETcjGO+kq/jy2RshXcXLeE5qYk1EF+SP8tn8Sw2MyEN+Xkrw3gUs2LFlfVotThFwLMg/uHD9MPy2Qn0kwJXbcNi9lavR1PTgliTrVX+5O0k2lzKdKWvV0UrI/I2IbwdE5ioaJtaTwldTMpchTIifFuWZcajXdQOVWDNimHqELf8vRjXW/mutSqupi2ZSobml2XRor1zwlvJd4xJudIUrFWXE5SLcqICcs6LNp4DRUTINWnK3Hm9Sog1OleJWkToFBV6xi39+qqqIa9+aVHTFqNSvVpTwOUtn1b7oJz/i36oXqlLZ+XECjS9PmVZvZhf1VVU+wmxyVZsz4l8SwnuZtabu8KidT8tlgHUnYzwXK7if03Q80rC9UkKyvNv43SrnWlG9AvguFhveMwzQkvTgoDYj2bEP1ByzietbCl7qxMUvCb20zHqoh7qhs55a6fhUjVR0XUrv8r13azuc+IMiAgs1W2x1ucRU+4ls1ZmwGEe2PLulrPqebWMt8/g3HMVnrfyRE54ISNWoBnTsgRe0cPCS6qQNF+pBbfebc2sjohoaZX1ba77jPDh/JIVmREZa86NWFx0q68ty9J8pRKb+0c5tkvrhmrtbcmq/FuKmV5Sz356nmREPyp2uby1ls3nE1Nua0XOcgvMlTFnxSD2E3xWfkJZvrJu5Xs+JyFa20G/A3ee81OVuvN27qYOP6tvF7kv7ia33ntuZUH1vrZUr/6qHOCWmLbkhbzys2JW7KnzViWdE5anxTp/p9zTlmSVLuKStmDeegJRrZ0wY+2H5rNhueaZfGJit8m8Y46aT7EpKzKL3MsrpFxnef7ExJ4Xt/wceNuznvl0kfuZ6oG5E3BbToF7eQc4hVZUaHVMVE3O1ay742g/AMoRUZHN9UOVv9VT+nX+t4dueTDrzv/ukTwVT0StdjSaSM3g/mFc3Tmzzf86UDd/iZlIpxN4Dd4V2NUb6OhXC9Ppzul8n9oV2Mm7M4n5TCx3OD7Vp/YEcParyRyfleCYjkBvYHc/f3MRr9kzcf5dwmycv5D2qd2RyM6OSHfksJZPtaqD89lEq3ogq+vnW9XZeJuJnZppMwdyWatROC8aP9Mk4QFGDvGrkbUC7iIpnck9wPqJ5vCexBRic3hVYjaS4nhFYnvgVQdtxiaxR/xPKYnx786I6m97Svw/J/43lYBjHwLrLK6rQoYk6KKiLYs2WfgmMwDSGNqTwGzCxX9bwLCM+PeMfVhajPbiZBRE+WB0hvh3i5fp3wE+Sc8CfoquAf4+vQ74D/R9wDegL2M1kMNYPWsAbGI7AP3sGOBxFgHU2SXA97Ei4K+yTwE+x56Hbi+yF9G+yl4C/AP2B4CvsC8C/jf+3Sv7U/Y/AP+cfRXwm+ybgN9m3wb8G/a3gN9nkM7eYD8E/BErEZNkqQawVqoHbOJ/60paLW0BdEt3ArZKAcBuqRdwj3Q34KB0BPC4dBxwXJoAPCmdAgxLpwEnJfhIikrnAJNSEjAjZQDnpMuAj0qPAj4h/RrgR6TfAHxG+gTgc9IC4O9Jvwf4GekzgC9JsEv6Q+kVwC9IsEv6U+nPAL8q/QXg16SvAX5D+gbgX0nfAvy2BBul70h/D/h/pH8A/L4ES6UfSjcAb0o3ickwFbBGhs/lJrkJ0Ck7AVfLqwHXy+sBN8obAW+XbwfcKrcBdsgdgEF5H+CgPEhM2asg1sqQMgR4n3If4MeUjwF+UnmeZOUF5dNov6j8JdpfV76O9neVvwN83WYTuSyL76gJOURY9fzvez2vvKZ8Qfkj5JeMeS8RKf9V+RzZlD8Bj0aeg8rvK5///5vJP6ENCmVuZHN0cmVhbQ0KZW5kb2JqDQoyMCAwIG9iag0KPDwvVHlwZS9NZXRhZGF0YS9TdWJ0eXBlL1hNTC9MZW5ndGggMzA5MT4+DQpzdHJlYW0NCjw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+PHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iMy4xLTcwMSI+CjxyZGY6UkRGIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyI+CjxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiICB4bWxuczpwZGY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGRmLzEuMy8iPgo8cGRmOlByb2R1Y2VyPk1pY3Jvc29mdMKuIFdvcmQgZsO8ciBNaWNyb3NvZnQgMzY1PC9wZGY6UHJvZHVjZXI+PC9yZGY6RGVzY3JpcHRpb24+CjxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iPgo8ZGM6Y3JlYXRvcj48cmRmOlNlcT48cmRmOmxpPlNjaMO2biwgSm9uYXM8L3JkZjpsaT48L3JkZjpTZXE+PC9kYzpjcmVhdG9yPjwvcmRmOkRlc2NyaXB0aW9uPgo8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiAgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIj4KPHhtcDpDcmVhdG9yVG9vbD5NaWNyb3NvZnTCriBXb3JkIGbDvHIgTWljcm9zb2Z0IDM2NTwveG1wOkNyZWF0b3JUb29sPjx4bXA6Q3JlYXRlRGF0ZT4yMDI2LTAyLTI3VDE0OjE3OjM4KzAxOjAwPC94bXA6Q3JlYXRlRGF0ZT48eG1wOk1vZGlmeURhdGU+MjAyNi0wMi0yN1QxNDoxNzozOCswMTowMDwveG1wOk1vZGlmeURhdGU+PC9yZGY6RGVzY3JpcHRpb24+CjxyZGY6RGVzY3JpcHRpb24gcmRmOmFib3V0PSIiICB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyI+Cjx4bXBNTTpEb2N1bWVudElEPnV1aWQ6RjI2NEM4NUYtM0Y5Ni00QzRGLUIyQTUtMzhDQjQ3OUJBMDFDPC94bXBNTTpEb2N1bWVudElEPjx4bXBNTTpJbnN0YW5jZUlEPnV1aWQ6RjI2NEM4NUYtM0Y5Ni00QzRGLUIyQTUtMzhDQjQ3OUJBMDFDPC94bXBNTTpJbnN0YW5jZUlEPjwvcmRmOkRlc2NyaXB0aW9uPgogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKPC9yZGY6UkRGPjwveDp4bXBtZXRhPjw/eHBhY2tldCBlbmQ9InciPz4NCmVuZHN0cmVhbQ0KZW5kb2JqDQoyMSAwIG9iag0KPDwvRGlzcGxheURvY1RpdGxlIHRydWU+Pg0KZW5kb2JqDQoyMiAwIG9iag0KPDwvVHlwZS9YUmVmL1NpemUgMjIvV1sgMSA0IDJdIC9Sb290IDEgMCBSL0luZm8gOSAwIFIvSURbPDVGQzg2NEYyOTYzRjRGNENCMkE1MzhDQjQ3OUJBMDFDPjw1RkM4NjRGMjk2M0Y0RjRDQjJBNTM4Q0I0NzlCQTAxQz5dIC9GaWx0ZXIvRmxhdGVEZWNvZGUvTGVuZ3RoIDg0Pj4NCnN0cmVhbQ0KeJxjYACC//8ZgaQgAwOIWgyhboMpxpdgiuk4mGLOAVMskRCqD0IdBsqDtTNBKGYIxQKhWCEUI4SCqmQD6mN9BtbO3gWhloIpJYhF+roMDAD1zQt7DQplbmRzdHJlYW0NCmVuZG9iag0KeHJlZg0KMCAyMw0KMDAwMDAwMDAxMCA2NTUzNSBmDQowMDAwMDAwMDE3IDAwMDAwIG4NCjAwMDAwMDAxNjMgMDAwMDAgbg0KMDAwMDAwMDIxOSAwMDAwMCBuDQowMDAwMDAwNDg5IDAwMDAwIG4NCjAwMDAwMDA3MTEgMDAwMDAgbg0KMDAwMDAwMDg3NiAwMDAwMCBuDQowMDAwMDAxMTEzIDAwMDAwIG4NCjAwMDAwMDExNjYgMDAwMDAgbg0KMDAwMDAwMTIxOSAwMDAwMCBuDQowMDAwMDAwMDExIDY1NTM1IGYNCjAwMDAwMDAwMTIgNjU1MzUgZg0KMDAwMDAwMDAxMyA2NTUzNSBmDQowMDAwMDAwMDE0IDY1NTM1IGYNCjAwMDAwMDAwMTUgNjU1MzUgZg0KMDAwMDAwMDAxNiA2NTUzNSBmDQowMDAwMDAwMDE3IDY1NTM1IGYNCjAwMDAwMDAwMDAgNjU1MzUgZg0KMDAwMDAwMTkzMCAwMDAwMCBuDQowMDAwMDAxOTU3IDAwMDAwIG4NCjAwMDAwMDg5MDMgMDAwMDAgbg0KMDAwMDAxMjA3NyAwMDAwMCBuDQowMDAwMDEyMTIyIDAwMDAwIG4NCnRyYWlsZXINCjw8L1NpemUgMjMvUm9vdCAxIDAgUi9JbmZvIDkgMCBSL0lEWzw1RkM4NjRGMjk2M0Y0RjRDQjJBNTM4Q0I0NzlCQTAxQz48NUZDODY0RjI5NjNGNEY0Q0IyQTUzOENCNDc5QkEwMUM+XSA+Pg0Kc3RhcnR4cmVmDQoxMjQwNQ0KJSVFT0YNCnhyZWYNCjAgMA0KdHJhaWxlcg0KPDwvU2l6ZSAyMy9Sb290IDEgMCBSL0luZm8gOSAwIFIvSURbPDVGQzg2NEYyOTYzRjRGNENCMkE1MzhDQjQ3OUJBMDFDPjw1RkM4NjRGMjk2M0Y0RjRDQjJBNTM4Q0I0NzlCQTAxQz5dIC9QcmV2IDEyNDA1L1hSZWZTdG0gMTIxMjI+Pg0Kc3RhcnR4cmVmDQoxMzAyMQ0KJSVFT0Y="
        }
      }]
    },
    "response" : {
      "status" : "200"
    }
  },
  {
    "fullUrl" : "urn:uuid:7f4a8b2e-9c1d-4e5f-a6b8-3c2d9e1f0a7b",
    "resource" : {
      "resourceType" : "DocumentReference",
      "id" : "BeispielDocumentReferenceRechnungRetrieve2",
      "meta" : {
        "profile" : ["https://gematik.de/fhir/dipag/StructureDefinition/dipag-dokumentenmetadaten-intern"]
      },
      "text" : {
        "status" : "generated",
        "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"DocumentReference_BeispielDocumentReferenceRechnungRetrieve2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: DocumentReference BeispielDocumentReferenceRechnungRetrieve2</b></p><a name=\"BeispielDocumentReferenceRechnungRetrieve2\"> </a><a name=\"hcBeispielDocumentReferenceRechnungRetrieve2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-dipag-dokumentenmetadaten-intern.html\">Digitale Patientenrechnung Dokumentenmetadaten Intern</a></p></div><p><b>identifier</b>: <code>https://gematik.de/fhir/sid/dipag-token</code>/123-456-123</p><p><b>status</b>: Current</p><p><b>type</b>: <span title=\"Codes:{http://dvmd.de/fhir/CodeSystem/kdl AM010106}\">Rechnung ambulante/stationäre Behandlung</span></p><p><b>subject</b>: Erika Mustermann</p><p><b>description</b>: Rechnung Reiseimpfung vom 11.01.2024</p><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>application/pdf</td><td><a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/[FD-endpunkt]/Binary/id-der-originalen-rechnung2\">[FD-endpunkt]/Binary/id-der-originalen-rechnung2</a></td></tr></table><p><b>format</b>: <a href=\"CodeSystem-dipag-attachment-format-cs.html#dipag-attachment-format-cs-originaleRechnung\">Digitale Patientenrechnung Attachment Format CS: originaleRechnung</a> (Das originale PDF der Rechnung)</p></blockquote><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>application/fhir+json</td><td><a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/[FD-endpunkt]/Binary/id-des-strukturierten-rechnungsinhalts2\">[FD-endpunkt]/Binary/id-des-strukturierten-rechnungsinhalts2</a></td></tr></table><p><b>format</b>: <a href=\"CodeSystem-dipag-attachment-format-cs.html#dipag-attachment-format-cs-rechnungsinhalt\">Digitale Patientenrechnung Attachment Format CS: rechnungsinhalt</a> (Strukturierter Rechnungsinhalt)</p></blockquote><blockquote><p><b>content</b></p><h3>Attachments</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>ContentType</b></td><td><b>Url</b></td></tr><tr><td style=\"display: none\">*</td><td>application/pdf</td><td><a href=\"https://simplifier.net/resolve?scope=de.basisprofil.r4@1.5.4&amp;canonical=http://fhir.org/packages/de.basisprofil.r4/[FD-endpunkt]/Binary/id-des-angereicherten-pdfs2\">[FD-endpunkt]/Binary/id-des-angereicherten-pdfs2</a></td></tr></table><p><b>format</b>: <a href=\"CodeSystem-dipag-attachment-format-cs.html#dipag-attachment-format-cs-angereichertesPDF\">Digitale Patientenrechnung Attachment Format CS: angereichertesPDF</a> (Digitale Patientenrechnungs Dokument mit eingebetteten strukturierten Rechnungsinhalt)</p></blockquote></div>"
      },
      "identifier" : [{
        "system" : "https://gematik.de/fhir/sid/dipag-token",
        "value" : "123-456-123"
      }],
      "status" : "current",
      "type" : {
        "coding" : [{
          "system" : "http://dvmd.de/fhir/CodeSystem/kdl",
          "code" : "AM010106",
          "display" : "Rechnung ambulante/stationäre Behandlung"
        }]
      },
      "subject" : {
        "display" : "Erika Mustermann"
      },
      "description" : "Rechnung Reiseimpfung vom 11.01.2024",
      "content" : [{
        "attachment" : {
          "contentType" : "application/pdf",
          "url" : "[FD-endpunkt]/Binary/id-der-originalen-rechnung2"
        },
        "format" : {
          "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
          "code" : "originaleRechnung"
        }
      },
      {
        "attachment" : {
          "contentType" : "application/fhir+json",
          "url" : "[FD-endpunkt]/Binary/id-des-strukturierten-rechnungsinhalts2"
        },
        "format" : {
          "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
          "code" : "rechnungsinhalt"
        }
      },
      {
        "attachment" : {
          "contentType" : "application/pdf",
          "url" : "[FD-endpunkt]/Binary/id-des-angereicherten-pdfs2"
        },
        "format" : {
          "system" : "https://gematik.de/fhir/dipag/CodeSystem/dipag-attachment-format-cs",
          "code" : "angereichertesPDF"
        }
      }]
    },
    "response" : {
      "status" : "200"
    }
  }]
}

```
